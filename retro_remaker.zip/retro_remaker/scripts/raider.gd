## Universal RPG Engine - raider.gd
## last modified (local): 2026-11-14-11-25-00
## instructions: on modify, update string.
extends CharacterBody3D

signal movement_finished(approach_found: bool)

@export var move_speed: float = 3.0

const MOVEMENT_STUCK_TIMEOUT := 0.75
const MOVEMENT_PROGRESS_EPSILON := 0.01

var navigation_agent: NavigationAgent3D
var navigation_map_ready := false
var is_moving := false
var movement_finish_pending := false
var movement_stuck_time := 0.0
var movement_distance := 0.0
var last_position := Vector3.ZERO
var combat_grid_path := PackedVector3Array()
var combat_grid_costs := PackedInt32Array()
var combat_grid_step_index := 0
var combat_grid_cost_in_action := 0
var combat_grid_active := false

func _debug_movement(message: String) -> void:
	var controller := get_tree().current_scene
	if controller != null and controller.has_method("debug_click_movement"):
		controller.call("debug_click_movement", "%s: %s" % [name, message])

func _ready() -> void:
	navigation_agent = NavigationAgent3D.new()
	navigation_agent.path_desired_distance = 0.25
	navigation_agent.target_desired_distance = 0.25
	add_child(navigation_agent)
	navigation_agent.navigation_finished.connect(_on_navigation_finished)

func move_toward_target(target: CollisionObject3D, stop_distance: float) -> void:
	if target == null:
		movement_finished.emit(false)
		return
	var controller := get_tree().current_scene
	if controller != null and controller.has_method("uses_tactical_grid") and bool(controller.call("uses_tactical_grid")):
		var grid_route: Dictionary = controller.call("get_combat_grid_approach_route", self, target)
		if grid_route.is_empty() or not grid_route.has("path") or (grid_route["path"] as PackedVector3Array).size() < 2:
			movement_finished.emit(false)
			return
		combat_grid_path = grid_route["path"]
		combat_grid_costs = grid_route["step_costs"]
		combat_grid_step_index = 1
		combat_grid_cost_in_action = 0
		combat_grid_active = true
		controller.call("begin_opportunity_movement", name)
		is_moving = true
		movement_finish_pending = false
		movement_stuck_time = 0.0
		_debug_movement("grid route=%s costs=%s" % [combat_grid_path, combat_grid_costs])
		_start_next_grid_step()
		return

	var direction_to_target := target.global_position - global_position
	direction_to_target.y = 0.0
	if direction_to_target.length_squared() < 0.0001:
		movement_finished.emit(false)
		return

	var approach_position := target.global_position - direction_to_target.normalized() * stop_distance
	approach_position.y = global_position.y
	var navigation_map := navigation_agent.get_navigation_map()
	if NavigationServer3D.map_get_iteration_id(navigation_map) != 0:
		var best_length := INF
		var found_position := false
		for index in range(16):
			var offset := (-direction_to_target.normalized() * stop_distance).rotated(Vector3.UP, TAU * index / 16.0)
			var candidate := target.global_position + offset
			candidate.y = global_position.y
			var path := NavigationServer3D.map_get_path(navigation_map, global_position, candidate, true)
			if path.is_empty() or path[path.size() - 1].distance_to(candidate) > 0.3:
				continue
			var shape := SphereShape3D.new()
			shape.radius = 0.4
			var shape_query := PhysicsShapeQueryParameters3D.new()
			shape_query.shape = shape
			shape_query.transform = Transform3D(Basis.IDENTITY, candidate + Vector3.UP * 0.6)
			shape_query.exclude = [get_rid()]
			if not get_world_3d().direct_space_state.intersect_shape(shape_query, 1).is_empty():
				continue
			var query := PhysicsRayQueryParameters3D.create(candidate + Vector3.UP * 0.6, target.global_position + Vector3.UP * 0.6)
			query.exclude = [get_rid(), target.get_rid()]
			if not get_world_3d().direct_space_state.intersect_ray(query).is_empty():
				continue
			var path_length := 0.0
			for path_index in range(1, path.size()):
				path_length += path[path_index - 1].distance_to(path[path_index])
			if path_length < best_length:
				best_length = path_length
				approach_position = candidate
				found_position = true
		if not found_position:
			movement_finished.emit(false)
			return
	is_moving = true
	movement_finish_pending = false
	movement_stuck_time = 0.0
	movement_distance = 0.0
	last_position = global_position
	navigation_agent.target_position = approach_position

func move_to_test_destination(destination: Vector3) -> bool:
	var controller := get_tree().current_scene
	if controller == null or not controller.has_method("uses_tactical_grid") or not bool(controller.call("uses_tactical_grid")):
		return false
	var grid_route: Dictionary = controller.call("get_combat_grid_route", self, destination)
	if grid_route.is_empty() or not grid_route.has("path") or (grid_route["path"] as PackedVector3Array).size() < 2:
		return false
	combat_grid_path = grid_route["path"]
	combat_grid_costs = grid_route["step_costs"]
	combat_grid_step_index = 1
	combat_grid_cost_in_action = 0
	combat_grid_active = true
	controller.call("begin_opportunity_movement", name)
	is_moving = true
	movement_finish_pending = false
	movement_stuck_time = 0.0
	_debug_movement("test grid route=%s costs=%s" % [combat_grid_path, combat_grid_costs])
	_start_next_grid_step()
	return true

func cancel_movement() -> void:
	if not is_moving:
		return

	is_moving = false
	movement_finish_pending = false
	movement_stuck_time = 0.0
	combat_grid_active = false
	velocity = Vector3.ZERO
	movement_finished.emit(true)

func _physics_process(_delta: float) -> void:
	var controller := get_tree().current_scene
	if not navigation_map_ready:
		var navigation_map := navigation_agent.get_navigation_map()
		if NavigationServer3D.map_get_iteration_id(navigation_map) == 0:
			velocity = Vector3.ZERO
			move_and_slide()
			return
		navigation_map_ready = true

	if not is_moving:
		velocity = Vector3.ZERO
		move_and_slide()
		return

	if movement_finish_pending:
		if combat_grid_active:
			movement_finish_pending = false
			_arrive_at_grid_step()
			return
		_finish_movement()
		return

	var next_position := navigation_agent.get_next_path_position()
	if not is_moving:
		return
	if navigation_agent.is_navigation_finished():
		if combat_grid_active:
			_arrive_at_grid_step()
			return
		_finish_movement()
		return

	var direction := global_position.direction_to(next_position)
	velocity.x = direction.x * move_speed
	velocity.z = direction.z * move_speed
	if not combat_grid_active and _delta > 0.0:
		var remaining_distance := maxf(float(controller.call("get_combat_movement_limit", name)) - movement_distance, 0.0)
		velocity = velocity.limit_length(remaining_distance / _delta)
	var position_before_move := global_position
	move_and_slide()
	movement_distance += global_position.distance_to(position_before_move)
	if not combat_grid_active and movement_distance >= float(controller.call("get_combat_movement_limit", name)) - 0.001:
		_finish_movement()
		return
	movement_stuck_time += _delta
	if movement_stuck_time >= MOVEMENT_STUCK_TIMEOUT:
		if global_position.distance_to(last_position) <= MOVEMENT_PROGRESS_EPSILON:
			_finish_movement()
		else:
			last_position = global_position
			movement_stuck_time = 0.0

func _on_navigation_finished() -> void:
	if is_moving:
		movement_finish_pending = true

func _finish_movement() -> void:
	if not is_moving:
		return

	is_moving = false
	movement_finish_pending = false
	movement_stuck_time = 0.0
	velocity = Vector3.ZERO
	move_and_slide()
	_debug_movement("movement finished at=%s" % global_position)
	movement_finished.emit(true)

func _start_next_grid_step() -> void:
	if not combat_grid_active:
		return
	if combat_grid_step_index >= combat_grid_path.size():
		combat_grid_active = false
		_finish_movement()
		return
	var controller := get_tree().current_scene
	var step_cost := combat_grid_costs[combat_grid_step_index - 1]
	if combat_grid_cost_in_action > 0 and combat_grid_cost_in_action + step_cost > int(controller.call("get_combat_movement_limit", name)):
		combat_grid_active = false
		_finish_movement()
		return
	if not controller.before_combat_grid_step(self, combat_grid_path[combat_grid_step_index], false):
		is_moving = false
		combat_grid_active = false
		velocity = Vector3.ZERO
		return
	navigation_agent.target_desired_distance = 0.05
	navigation_agent.target_position = combat_grid_path[combat_grid_step_index]
	_debug_movement("grid step=%d cost=%d target=%s" % [combat_grid_step_index, step_cost, navigation_agent.target_position])

func _arrive_at_grid_step() -> void:
	if not combat_grid_active or combat_grid_step_index >= combat_grid_path.size():
		return
	global_position = combat_grid_path[combat_grid_step_index]
	combat_grid_cost_in_action += combat_grid_costs[combat_grid_step_index - 1]
	_debug_movement("grid step reached=%s accumulated_cost=%d" % [global_position, combat_grid_cost_in_action])
	combat_grid_step_index += 1
	_start_next_grid_step()
