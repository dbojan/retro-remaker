## Universal RPG Engine - main.gd
## last modified (local): 2026-11-14-12-07-35
## instructions: on modify, update string.
extends Node3D

const GridNavigation = preload("res://scripts/grid_navigation.gd")
const CHARACTER_DATA_PATH := "res://data/characters/player.json"
const RACE_DATA_PATH := "res://data/races.json"
const CLASS_DATA_PATH := "res://data/classes.json"
const SKILL_DATA_PATH := "res://data/skills.json"
const FEAT_DATA_PATH := "res://data/feats.json"
const MELEE_ATTACK_RANGE := 2.0
const FEET_PER_GRID_CELL := 5
const DEFAULT_COMBAT_SPEED_FEET := 30
const SWITCH_MOVE_CHARACTER_TOWARDS_ENEMY_ALWAYS := true
const SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION := true
const SWITCH_TURN_END_PRESSED_AUTOMATICALLY_IF_NO_ACTION_POINTS_LEFT := true
const SWITCH_ACTIVE_ACTOR_TEXT_COLOR := Color(1.0, 0.12, 0.12, 1.0)
const SWITCH_TEXT_BOX_WIDTH_RATIO := 0.5
const SWITCH_TEXT_BOX_FONT_SIZE := 14
const SWITCH_DEBUG_CLICK_AND_MOVEMENT := true
const MAX_PARTY_HEALTH := 20
const HEALING_POTION_AMOUNT := 10
const DEFAULT_CAMERA_SIZE := 14.0
const MIN_CAMERA_SIZE := 6.0
const MAX_CAMERA_SIZE := 20.0
const CAMERA_ZOOM_STEP := 1.0
const CAMERA_ROTATION_SENSITIVITY := 0.01
const CAMERA_DRAG_THRESHOLD := 6.0
const CAMERA_ORBIT_TARGET := Vector3.ZERO
const SAVE_GAME_PATH := "res://savegame.cfg"
const LEGACY_SAVE_GAME_PATH := "user://savegame.cfg"
const SAVE_GAME_VERSION := 1
const COMMAND_PORT := 47831
const MAX_COMMAND_BYTES := 4096
const INSPECT_RECENT_LOG_LIMIT := 20

var combat_active := false
var combat_turn_order: Array[String] = []
var current_turn_index := 0
var combat_round := 1
const ACTION_POINTS_PER_TURN := 2
const SWITCH_STANDARD_MOVE_ACTIONS := true
var action_points := ACTION_POINTS_PER_TURN
var party_action_points: Dictionary = {}
var party_standard_available: Dictionary = {}
var party_move_available: Dictionary = {}
var party_five_foot_step_available: Dictionary = {}
var enemy_standard_available: Dictionary = {}
var enemy_move_available: Dictionary = {}
var attack_button: Button
var charge_button: Button
var withdraw_button: Button
var full_attack_button: Button
var power_attack_selector: OptionButton
var feat_selector: OptionButton
var power_attack_penalties: Dictionary = {}
var power_attack_locked: Dictionary = {}
var defend_button: Button
var end_turn_button: Button
var potion_button: Button
var five_foot_step_button: Button
var weapon_selector: OptionButton
var combat_enemy_name := ""
var combat_enemy_health: Dictionary = {}
var combat_log_label: RichTextLabel
var combat_log_panel: PanelContainer
var combat_log_history := PackedStringArray()
var movement_debug_log := PackedStringArray()
var combat_live_status := ""
var combat_log_text := "":
	set(value):
		var previous := combat_log_text
		combat_log_text = value
		if value.is_empty():
			return
		if not previous.is_empty() and value.length() > previous.length() and value.begins_with(previous) and not combat_log_history.is_empty():
			combat_log_history[combat_log_history.size() - 1] = value
		else:
			combat_log_history.append(value)
			if combat_log_history.size() > 100:
				combat_log_history.remove_at(0)
		_refresh_combat_log()
var party_health: Dictionary = {}
var party_defending: Dictionary = {}
var party_charge_pending: Dictionary = {}
var party_charge_defending: Dictionary = {}
var enemy_turn_in_progress := false
var enemy_move_cancelled := false
var actor_base_name_colors: Dictionary = {}
var dialogue_panel: PanelContainer
var dialogue_text: Label
var dialogue_choice_button: Button
var dialogue_decline_button: Button
var dialogue_influence_button: Button
var dialogue_lore_button: Button
var quest_flags: Dictionary = {}
var inventory: Dictionary = {}
var save_status_text := ""
var exploration_camera: Camera3D
var right_mouse_down := false
var right_mouse_dragged := false
var right_mouse_press_position := Vector2.ZERO
var party_character_data: Dictionary = {}
var feat_definitions: Dictionary = {}
var party_selected_feats: Dictionary = {}
var party_skill_totals: Dictionary = {}
var party_weapon_data: Dictionary = {}
var equipped_weapons: Dictionary = {}
var command_input: LineEdit
var command_menu: MenuButton
var action_scroll: ScrollContainer
var party_buttons: VBoxContainer
var command_panel: Control
var command_server := TCPServer.new()
var command_client: StreamPeerTCP
var command_buffer := PackedByteArray()
var command_client_elapsed := 0.0
var targeting_line: MeshInstance3D
var target_materials: Dictionary = {}
var ctrl_down := false
var combat_grid := GridNavigation.new()
var opportunity_remaining: Dictionary = {}
var opportunity_movement_attackers: Dictionary = {}
var opportunity_acted: Dictionary = {}
var difficult_terrain_cell_costs: Dictionary = {}
var impassable_terrain_cells: Dictionary = {}

func _ready() -> void:
	_migrate_legacy_save()
	_load_combat_terrain()
	var listen_error := command_server.listen(COMMAND_PORT, "127.0.0.1")
	if listen_error != OK:
		push_warning("Could not start the local command connection: %s" % error_string(listen_error))
	exploration_camera = get_node_or_null("Camera3D") as Camera3D
	if exploration_camera != null:
		exploration_camera.size = DEFAULT_CAMERA_SIZE
	combat_log_panel = get_node_or_null("CombatUI/LogPanel") as PanelContainer
	if combat_log_panel != null:
		var width_ratio := clampf(SWITCH_TEXT_BOX_WIDTH_RATIO, 0.0, 1.0)
		combat_log_panel.anchor_right = width_ratio
		combat_log_panel.offset_right = 20.0 - 40.0 * width_ratio
	combat_log_label = get_node_or_null("CombatUI/LogPanel/CombatLog") as RichTextLabel
	if combat_log_label != null:
		combat_log_label.bbcode_enabled = true
		combat_log_label.add_theme_font_size_override("normal_font_size", maxi(1, SWITCH_TEXT_BOX_FONT_SIZE))
	attack_button = get_node_or_null("CombatUI/ActionScroll/Actions/AttackButton") as Button
	charge_button = get_node_or_null("CombatUI/ActionScroll/Actions/ChargeButton") as Button
	withdraw_button = get_node_or_null("CombatUI/ActionScroll/Actions/WithdrawButton") as Button
	full_attack_button = get_node_or_null("CombatUI/ActionScroll/Actions/FullAttackButton") as Button
	power_attack_selector = get_node_or_null("CombatUI/ActionScroll/Actions/PowerAttackSelector") as OptionButton
	feat_selector = get_node_or_null("CombatUI/ActionScroll/Actions/FeatSelector") as OptionButton
	defend_button = get_node_or_null("CombatUI/ActionScroll/Actions/DefendButton") as Button
	end_turn_button = get_node_or_null("CombatUI/ActionScroll/Actions/EndTurnButton") as Button
	potion_button = get_node_or_null("CombatUI/ActionScroll/Actions/UsePotionButton") as Button
	five_foot_step_button = get_node_or_null("CombatUI/ActionScroll/Actions/FiveFootStepButton") as Button
	weapon_selector = get_node_or_null("CombatUI/ActionScroll/Actions/WeaponSelector") as OptionButton
	dialogue_panel = get_node_or_null("CombatUI/DialoguePanel") as PanelContainer
	dialogue_text = get_node_or_null("CombatUI/DialoguePanel/DialogueContent/DialogueText") as Label
	dialogue_choice_button = get_node_or_null("CombatUI/DialoguePanel/DialogueContent/DialogueChoiceButton") as Button
	dialogue_decline_button = get_node_or_null("CombatUI/DialoguePanel/DialogueContent/DialogueDeclineButton") as Button
	dialogue_influence_button = get_node_or_null("CombatUI/DialoguePanel/DialogueContent/DialogueInfluenceButton") as Button
	dialogue_lore_button = get_node_or_null("CombatUI/DialoguePanel/DialogueContent/DialogueLoreButton") as Button
	command_input = get_node_or_null("CombatUI/CommandPanel/CommandContent/CommandInput") as LineEdit
	command_menu = get_node_or_null("CombatUI/CommandPanel/CommandContent/CommandMenu") as MenuButton
	action_scroll = get_node_or_null("CombatUI/ActionScroll") as ScrollContainer
	party_buttons = get_node_or_null("CombatUI/PartyButtons") as VBoxContainer
	if party_buttons != null:
		var adventurer_button := party_buttons.get_node_or_null("AdventurerButton") as Button
		var scout_button := party_buttons.get_node_or_null("ScoutButton") as Button
		if adventurer_button != null:
			adventurer_button.pressed.connect(_select_party_from_button.bind("Player"))
		if scout_button != null:
			scout_button.pressed.connect(_select_party_from_button.bind("Scout"))
	command_panel = get_node_or_null("CombatUI/CommandPanel") as Control
	if command_input != null:
		command_input.text_submitted.connect(_submit_text_command)
	if command_menu != null:
		var popup := command_menu.get_popup()
		for command_name in ["inspect", "start_combat", "end_turn", "move", "five_foot_step", "withdraw", "attack", "charge", "full_attack", "defend", "use_potion", "select", "choose_feat", "interact", "dialogue_choice", "dialogue_influence", "dialogue_lore", "dialogue_decline", "equip", "save", "load"]:
			popup.add_item(command_name)
		popup.id_pressed.connect(_on_command_menu_selected)
	if attack_button != null:
		attack_button.pressed.connect(_attack_current_enemy)
	if charge_button != null:
		charge_button.pressed.connect(_charge_current_enemy)
	if withdraw_button != null:
		withdraw_button.pressed.connect(_begin_withdraw)
	if full_attack_button != null:
		full_attack_button.pressed.connect(_full_attack_current_enemy)
	if power_attack_selector != null:
		power_attack_selector.item_selected.connect(_on_power_attack_selected)
	if feat_selector != null:
		feat_selector.item_selected.connect(_on_feat_selected)
	if defend_button != null:
		defend_button.pressed.connect(_defend_current_actor)
	if end_turn_button != null:
		end_turn_button.pressed.connect(_resolve_current_turn)
	if potion_button != null:
		potion_button.pressed.connect(_use_healing_potion)
	if five_foot_step_button != null:
		five_foot_step_button.pressed.connect(_begin_five_foot_step)
	if weapon_selector != null:
		weapon_selector.item_selected.connect(_on_weapon_selected)
	if dialogue_choice_button != null:
		dialogue_choice_button.pressed.connect(_accept_trail_quest)
	if dialogue_decline_button != null:
		dialogue_decline_button.pressed.connect(_decline_trail_quest)
	if dialogue_influence_button != null:
		dialogue_influence_button.pressed.connect(_use_trail_warden_influence)
	if dialogue_lore_button != null:
		dialogue_lore_button.pressed.connect(_use_trail_warden_lore)
	_restore_party_selection()
	_restore_party_health()
	_restore_quest_flags()
	_restore_inventory()
	_restore_equipped_weapons()
	_restore_party_selected_feats()
	_apply_pending_save_restore()
	for child in get_children():
		if child is Node3D and child.has_meta("combat_enemy") and bool(quest_flags.get(_enemy_defeated_flag(child.name), false)):
			child.queue_free()
	var key_pickup := get_node_or_null("IronKeyPickup")
	if key_pickup != null and bool(quest_flags.get("iron_key_collected", false)):
		key_pickup.queue_free()
	var supply_cache := get_node_or_null("LookoutSupplyCache")
	if supply_cache != null and bool(quest_flags.get("lookout_supply_cache_collected", false)):
		supply_cache.queue_free()
	var sword_pickup := get_node_or_null("IronSwordPickup")
	if sword_pickup != null and bool(quest_flags.get("iron_sword_collected", false)):
		sword_pickup.queue_free()
	if bool(quest_flags.get("lookout_gate_unlocked", false)):
		var gate_label := get_node_or_null("AreaExit/ExitLabel") as Label3D
		if gate_label != null:
			gate_label.text = "Open Gate"
	var skill_data := _load_skill_data()
	feat_definitions = _load_feat_data()
	for member in get_tree().get_nodes_in_group("party_members"):
		var data_path := str(member.get_meta("character_data_path", CHARACTER_DATA_PATH))
		var character_data := _load_character_data(data_path)
		if not character_data.is_empty():
			character_data = _apply_race_effects(character_data)
			character_data = _apply_class_effects(character_data)
			character_data = _apply_saved_feat_selection(member.name, character_data)
			if character_data.is_empty():
				continue
			var skill_totals := _load_character_skill_totals(character_data, skill_data)
			if skill_totals.is_empty():
				continue
			party_character_data[member.name] = character_data
			party_skill_totals[member.name] = skill_totals
			var weapon_id := str(equipped_weapons.get(member.name, character_data["equipped_weapon"]))
			party_weapon_data[member.name] = _load_weapon_data(weapon_id)
			var name_label := member.get_node_or_null("NameLabel") as Label3D
			if name_label != null:
				name_label.text = character_data["display_name"]
			print("Loaded character: %s (%s)" % [character_data["display_name"], character_data["id"]])
	for member in get_tree().get_nodes_in_group("party_members"):
		var max_health := _max_party_health(member.name)
		var health := mini(int(member.get_meta("health", max_health)), max_health)
		member.set_meta("health", health)
		party_health[member.name] = health
	_persist_party_health()
	_setup_target_visuals()
	_append_shared_text("Exploration")
	_append_shared_text("Click on the enemy to begin combat")
	var quest_objective := _quest_objective_text()
	if not quest_objective.is_empty():
		_append_shared_text(quest_objective)
	var inventory_status := _inventory_status_text()
	if not inventory_status.is_empty():
		_append_shared_text(inventory_status)
	_update_combat_display()

func start_dialogue(dialogue_id: String) -> void:
	if dialogue_id != "trail_warden" or combat_active:
		return
	var quest_started := bool(quest_flags.get("trail_marker_search_started", false))
	var plate_found := bool(quest_flags.get("trail_marker_found", false))
	var quest_completed := bool(quest_flags.get("trail_marker_quest_completed", false))
	if plate_found and not quest_completed:
		quest_flags["trail_marker_quest_completed"] = true
		_persist_quest_flags()
		inventory["healing_potions"] = int(inventory.get("healing_potions", 0)) + 1
		_persist_inventory()
		_update_combat_display()
	if dialogue_text != null:
		if bool(quest_flags.get("trail_marker_quest_completed", false)):
			dialogue_text.text = "You return the brass plate. The Trail Warden thanks you for bringing it back."
		elif quest_started:
			dialogue_text.text = "I’ll wait here for news about the missing brass plate."
		else:
			dialogue_text.text = "The old trail marker is missing its brass plate. Will you search the dungeon beyond the lookout for it?"
	if dialogue_text != null:
		_append_shared_text(dialogue_text.text)
	if dialogue_choice_button != null:
		dialogue_choice_button.text = "I’ll look for the plate." if not quest_started else "Close"
		dialogue_choice_button.visible = true
	if dialogue_decline_button != null:
		dialogue_decline_button.visible = not quest_started
	if dialogue_influence_button != null:
		var influence_total := get_party_skill_total(_selected_party_member_name(), "influence")
		dialogue_influence_button.text = "Influence (%+d): Ask for a clue." % influence_total
		dialogue_influence_button.tooltip_text = "Requires Influence +1 or higher."
		dialogue_influence_button.visible = not quest_started and not quest_completed
		dialogue_influence_button.disabled = influence_total < 1
	if dialogue_lore_button != null:
		var lore_total := get_party_skill_total(_selected_party_member_name(), "lore")
		dialogue_lore_button.text = "Lore (%+d): Recall the dungeon's history." % lore_total
		dialogue_lore_button.tooltip_text = "Requires Lore +1 or higher."
		dialogue_lore_button.visible = not quest_started and not quest_completed
		dialogue_lore_button.disabled = lore_total < 1
	if dialogue_panel != null:
		dialogue_panel.visible = true

func _accept_trail_quest() -> void:
	if bool(quest_flags.get("trail_marker_search_started", false)):
		if dialogue_panel != null:
			dialogue_panel.visible = false
		return
	if dialogue_choice_button != null:
		_append_shared_text(dialogue_choice_button.text)
	quest_flags["trail_marker_search_started"] = true
	_persist_quest_flags()
	if dialogue_text != null:
		dialogue_text.text = "Thank you. I’ll wait here for news. (Quest started)"
		_append_shared_text(dialogue_text.text)
	if dialogue_choice_button != null:
		dialogue_choice_button.text = "Close"
	if dialogue_decline_button != null:
		dialogue_decline_button.visible = false
	if dialogue_influence_button != null:
		dialogue_influence_button.visible = false
	if dialogue_lore_button != null:
		dialogue_lore_button.visible = false
	_update_combat_display()

func _decline_trail_quest() -> void:
	if dialogue_decline_button != null:
		_append_shared_text(dialogue_decline_button.text)
	if dialogue_panel != null:
		dialogue_panel.visible = false

func _use_trail_warden_influence() -> void:
	if bool(quest_flags.get("trail_marker_search_started", false)) or get_party_skill_total(_selected_party_member_name(), "influence") < 1:
		return
	quest_flags["trail_marker_search_started"] = true
	_persist_quest_flags()
	if dialogue_text != null:
		dialogue_text.text = "Your appeal earns a clue: the brass plate was last seen beyond the lookout. (Quest started)"
		_append_shared_text(dialogue_text.text)
	if dialogue_choice_button != null:
		dialogue_choice_button.text = "Close"
	if dialogue_decline_button != null:
		dialogue_decline_button.visible = false
	if dialogue_influence_button != null:
		dialogue_influence_button.visible = false
	if dialogue_lore_button != null:
		dialogue_lore_button.visible = false
	_update_combat_display()

func _use_trail_warden_lore() -> void:
	if bool(quest_flags.get("trail_marker_search_started", false)) or get_party_skill_total(_selected_party_member_name(), "lore") < 1:
		return
	quest_flags["trail_marker_search_started"] = true
	_persist_quest_flags()
	if dialogue_text != null:
		dialogue_text.text = "You recall the old marker guarded a sealed way through the dungeon. The brass plate should be beyond the lookout. (Quest started)"
		_append_shared_text(dialogue_text.text)
	if dialogue_choice_button != null:
		dialogue_choice_button.text = "Close"
	if dialogue_decline_button != null:
		dialogue_decline_button.visible = false
	if dialogue_influence_button != null:
		dialogue_influence_button.visible = false
	if dialogue_lore_button != null:
		dialogue_lore_button.visible = false
	_update_combat_display()

func show_interaction_message(message: String) -> void:
	if not message.is_empty():
		_append_shared_text(message)
	_update_combat_display()

func interact_with_quest_target(target_id: String) -> String:
	if target_id != "brass_plate":
		return ""
	if not bool(quest_flags.get("trail_marker_search_started", false)):
		return "A brass plate lies here."
	if bool(quest_flags.get("trail_marker_found", false)):
		return "You already have the brass plate. Return it to the Trail Warden."
	if not bool(quest_flags.get(_enemy_defeated_flag("DungeonGuardian"), false)):
		return "Defeat the dungeon guardian before taking the brass plate."
	quest_flags["trail_marker_found"] = true
	_persist_quest_flags()
	_update_combat_display()
	return "You find the missing brass plate. Return it to the Trail Warden."

func pickup_item(item_id: String) -> bool:
	if item_id == "iron_key":
		if bool(quest_flags.get("iron_key_collected", false)):
			return false
		inventory["iron_keys"] = int(inventory.get("iron_keys", 0)) + 1
		quest_flags["iron_key_collected"] = true
	elif item_id == "lookout_supply_cache":
		if bool(quest_flags.get("lookout_supply_cache_collected", false)):
			return false
		inventory["healing_potions"] = int(inventory.get("healing_potions", 0)) + 1
		quest_flags["lookout_supply_cache_collected"] = true
	elif item_id == "iron_sword":
		if bool(quest_flags.get("iron_sword_collected", false)):
			return false
		inventory["iron_sword"] = 1
		quest_flags["iron_sword_collected"] = true
	else:
		return false
	_persist_inventory()
	_persist_quest_flags()
	_append_shared_text(_inventory_status_text())
	_update_combat_display()
	return true

func try_open_key_gate(key_item_id: String) -> String:
	if bool(quest_flags.get("lookout_gate_unlocked", false)):
		return ""
	if key_item_id != "iron_key":
		return "This gate requires a different key."
	if int(inventory.get("iron_keys", 0)) <= 0:
		return "The gate is locked. Find the Iron Key."
	inventory["iron_keys"] = int(inventory["iron_keys"]) - 1
	quest_flags["lookout_gate_unlocked"] = true
	_persist_inventory()
	_persist_quest_flags()
	_update_combat_display()
	return ""

func _restore_quest_flags() -> void:
	if not get_tree().has_meta("quest_flags"):
		return
	var saved_quest_flags: Variant = get_tree().get_meta("quest_flags")
	if saved_quest_flags is Dictionary:
		quest_flags = saved_quest_flags.duplicate(true)

func _persist_quest_flags() -> void:
	get_tree().set_meta("quest_flags", quest_flags.duplicate(true))

func _restore_inventory() -> void:
	if not get_tree().has_meta("inventory"):
		return
	var saved_inventory: Variant = get_tree().get_meta("inventory")
	if saved_inventory is Dictionary:
		inventory = saved_inventory.duplicate(true)

func _persist_inventory() -> void:
	get_tree().set_meta("inventory", inventory.duplicate(true))

func _restore_equipped_weapons() -> void:
	var saved: Variant = get_tree().get_meta("equipped_weapons", {})
	if saved is Dictionary:
		equipped_weapons = saved.duplicate(true)

func _persist_equipped_weapons() -> void:
	get_tree().set_meta("equipped_weapons", equipped_weapons.duplicate(true))

func _restore_party_selected_feats() -> void:
	var saved: Variant = get_tree().get_meta("party_selected_feats", {})
	if saved is Dictionary:
		party_selected_feats = saved.duplicate(true)

func _persist_party_selected_feats() -> void:
	get_tree().set_meta("party_selected_feats", party_selected_feats.duplicate(true))

func _save_game_path() -> String:
	return SAVE_GAME_PATH if OS.has_feature("editor") else LEGACY_SAVE_GAME_PATH

func _enemy_defeated_flag(enemy_name: String) -> String:
	return "defeated:%s:%s" % [scene_file_path, enemy_name]

func _is_combat_enemy(actor_name: String) -> bool:
	return combat_enemy_health.has(actor_name)

func _living_combat_enemies() -> Array[CollisionObject3D]:
	var enemies: Array[CollisionObject3D] = []
	for child in get_children():
		if child is CollisionObject3D and child.has_meta("combat_enemy") and not child.is_queued_for_deletion() and int(combat_enemy_health.get(child.name, child.get_meta("health", 0))) > 0:
			enemies.append(child)
	return enemies

func _current_enemy_turn_name() -> String:
	if combat_active and not combat_turn_order.is_empty() and _is_combat_enemy(combat_turn_order[current_turn_index]):
		return combat_turn_order[current_turn_index]
	return ""

func _selected_combat_enemy() -> CollisionObject3D:
	var enemy := get_node_or_null(combat_enemy_name) as CollisionObject3D
	if enemy != null and not enemy.is_queued_for_deletion() and int(combat_enemy_health.get(enemy.name, 0)) > 0:
		return enemy
	var enemies := _living_combat_enemies()
	if enemies.is_empty():
		return null
	combat_enemy_name = enemies[0].name
	return enemies[0]

func _migrate_legacy_save() -> void:
	if not OS.has_feature("editor"):
		return
	if FileAccess.file_exists(SAVE_GAME_PATH) or not FileAccess.file_exists(LEGACY_SAVE_GAME_PATH):
		return

	var legacy_save_bytes: PackedByteArray = FileAccess.get_file_as_bytes(LEGACY_SAVE_GAME_PATH)
	var portable_save := FileAccess.open(SAVE_GAME_PATH, FileAccess.WRITE)
	if portable_save == null:
		push_warning("Could not copy the existing save into the project folder.")
		return
	portable_save.store_buffer(legacy_save_bytes)
	portable_save.flush()
	var write_error := portable_save.get_error()
	portable_save.close()
	if write_error != OK:
		push_warning("Could not copy the existing save into the project folder: %s" % error_string(write_error))

func _save_game() -> void:
	if combat_active:
		_set_save_status("Save and load are available during exploration.")
		_update_combat_display()
		return
	var current_scene := get_tree().current_scene
	if current_scene == null or current_scene.scene_file_path.is_empty():
		_set_save_status("Could not save this scene.")
		_update_combat_display()
		return
	var party_data: Dictionary = {}
	var selected_member := ""
	for party_member in get_tree().get_nodes_in_group("party_members"):
		party_data[party_member.name] = {
			"position": party_member.global_position,
			"health": int(party_member.get_meta("health", MAX_PARTY_HEALTH))
		}
		if bool(party_member.get("is_selected")):
			selected_member = party_member.name
	var save_data := {
		"version": SAVE_GAME_VERSION,
		"scene_path": current_scene.scene_file_path,
		"inventory": inventory.duplicate(true),
		"equipped_weapons": equipped_weapons.duplicate(true),
		"party_selected_feats": party_selected_feats.duplicate(true),
		"quest_flags": quest_flags.duplicate(true),
		"selected_party_member": selected_member,
		"party": party_data
	}
	var save_file := ConfigFile.new()
	save_file.set_value("game", "data", save_data)
	var save_error := save_file.save(_save_game_path())
	if save_error != OK:
		_set_save_status("Save failed: %s" % error_string(save_error))
	else:
		_set_save_status("Game saved.")
	_update_combat_display()

func _load_game() -> void:
	if combat_active:
		_set_save_status("Save and load are available during exploration.")
		_update_combat_display()
		return
	var save_file := ConfigFile.new()
	var load_error := save_file.load(_save_game_path())
	if load_error != OK:
		_set_save_status("No saved game found." if load_error == ERR_FILE_NOT_FOUND else "Could not read the saved game.")
		_update_combat_display()
		return
	var save_data: Variant = save_file.get_value("game", "data", null)
	if not save_data is Dictionary or int(save_data.get("version", 0)) != SAVE_GAME_VERSION:
		_set_save_status("The saved game is invalid or incompatible.")
		_update_combat_display()
		return
	if not save_data.get("inventory", null) is Dictionary or not save_data.get("quest_flags", null) is Dictionary or not save_data.get("party", null) is Dictionary or not save_data.get("equipped_weapons", {}) is Dictionary or not save_data.get("party_selected_feats", {}) is Dictionary:
		_set_save_status("The saved game is invalid.")
		_update_combat_display()
		return
	var scene_path := str(save_data.get("scene_path", ""))
	if scene_path.is_empty() or not ResourceLoader.exists(scene_path):
		_set_save_status("The saved area could not be found.")
		_update_combat_display()
		return
	get_tree().set_meta("pending_save_restore", save_data.duplicate(true))
	get_tree().call_deferred("change_scene_to_file", scene_path)

func _apply_pending_save_restore() -> void:
	if not get_tree().has_meta("pending_save_restore"):
		return
	var save_data: Variant = get_tree().get_meta("pending_save_restore")
	get_tree().remove_meta("pending_save_restore")
	if not save_data is Dictionary:
		return
	var saved_inventory: Variant = save_data.get("inventory", {})
	var saved_quest_flags: Variant = save_data.get("quest_flags", {})
	var saved_party: Variant = save_data.get("party", {})
	var saved_weapons: Variant = save_data.get("equipped_weapons", {})
	var saved_feats: Variant = save_data.get("party_selected_feats", {})
	if not saved_inventory is Dictionary or not saved_quest_flags is Dictionary or not saved_party is Dictionary or not saved_weapons is Dictionary or not saved_feats is Dictionary:
		_set_save_status("The saved game is invalid.")
		return
	inventory = saved_inventory.duplicate(true)
	quest_flags = saved_quest_flags.duplicate(true)
	equipped_weapons = saved_weapons.duplicate(true)
	party_selected_feats = saved_feats.duplicate(true)
	_persist_inventory()
	_persist_quest_flags()
	_persist_equipped_weapons()
	_persist_party_selected_feats()
	var selected_member := str(save_data.get("selected_party_member", ""))
	var found_selected_member := false
	for party_member in get_tree().get_nodes_in_group("party_members"):
		var saved_actor: Variant = saved_party.get(party_member.name, {})
		if saved_actor is Dictionary:
			var saved_position: Variant = saved_actor.get("position")
			if saved_position is Vector3:
				party_member.global_position = saved_position
			if saved_actor.has("health"):
				party_member.set_meta("health", int(saved_actor["health"]))
		party_member.call("set_selected", party_member.name == selected_member)
		if party_member.name == selected_member:
			found_selected_member = true
		party_health[party_member.name] = int(party_member.get_meta("health", MAX_PARTY_HEALTH))
	if found_selected_member:
		get_tree().set_meta("selected_party_member", selected_member)
	else:
		_select_fallback_party_member()
	_persist_party_health()
	_set_save_status("Game loaded.")

func _set_save_status(message: String) -> void:
	save_status_text = message
	_append_shared_text(message)

func _current_potion_user() -> Node3D:
	if combat_active:
		if combat_turn_order.is_empty():
			return null
		var active_actor_name := combat_turn_order[current_turn_index]
		if not is_party_member_turn(active_actor_name):
			return null
		for party_member in get_tree().get_nodes_in_group("party_members"):
			if party_member.name == active_actor_name:
				return party_member as Node3D
		return null

	for party_member in get_tree().get_nodes_in_group("party_members"):
		if bool(party_member.get("is_selected")):
			return party_member as Node3D
	return null

func _max_party_health(actor_name: String) -> int:
	var data: Dictionary = party_character_data.get(actor_name, {})
	var attributes: Dictionary = data.get("attributes", {})
	if data.has("base_health") and attributes.has("constitution"):
		return maxi(1, int(data["base_health"]) + floori((float(attributes["constitution"]) - 10.0) / 2.0))
	return MAX_PARTY_HEALTH

func _current_party_health(party_member: Node3D) -> int:
	if combat_active:
		return int(party_health.get(party_member.name, party_member.get_meta("health", MAX_PARTY_HEALTH)))
	return int(party_member.get_meta("health", MAX_PARTY_HEALTH))

func _can_use_healing_potion() -> bool:
	if int(inventory.get("healing_potions", 0)) <= 0:
		return false
	var potion_user := _current_potion_user()
	return potion_user != null and (not combat_active or (action_points > 0 and _standard_available(potion_user.name) and not _actor_is_moving(potion_user))) and _current_party_health(potion_user) < _max_party_health(potion_user.name)

func _actor_is_moving(actor: Node) -> bool:
	return bool(actor.get("has_destination")) or bool(actor.get("has_pending_destination"))

func _use_healing_potion() -> void:
	if combat_active and action_points <= 0:
		return
	if int(inventory.get("healing_potions", 0)) <= 0:
		return
	var potion_user := _current_potion_user()
	if potion_user == null:
		return
	if combat_active and (not _standard_available(potion_user.name) or _actor_is_moving(potion_user)):
		return
	var current_health := _current_party_health(potion_user)
	var max_health := _max_party_health(potion_user.name)
	if current_health >= max_health:
		return
	if combat_active and not _resolve_opportunity_trigger(potion_user, false):
		return
	var healed_health := mini(current_health + HEALING_POTION_AMOUNT, max_health)
	var healing_done := healed_health - current_health
	potion_user.set_meta("health", healed_health)
	party_health[potion_user.name] = healed_health
	_persist_party_health()
	inventory["healing_potions"] = int(inventory["healing_potions"]) - 1
	_persist_inventory()
	if combat_active:
		combat_log_text = "%s uses a healing potion and restores %d HP." % [_actor_display_name(potion_user.name), healing_done]
	if combat_active:
		_consume_main_action()
	else:
		_update_combat_display()

func _append_shared_text(message: String) -> void:
	if message.is_empty():
		return
	combat_log_history.append(message)
	if combat_log_history.size() > 100:
		combat_log_history.remove_at(0)
	_refresh_combat_log()

func _append_action_usage(actor_name: String) -> void:
	var used_points := ACTION_POINTS_PER_TURN - _party_points(actor_name)
	_append_shared_text("%s used %d/%d points." % [_actor_display_name(actor_name), used_points, ACTION_POINTS_PER_TURN])

func _refresh_combat_log() -> void:
	if combat_log_label == null:
		return
	var displayed := PackedStringArray()
	if combat_active and not combat_live_status.is_empty():
		displayed.append(combat_live_status)
	for message in combat_log_history:
		displayed.append(message.replace("[", "[lb]"))
	combat_log_label.text = "\n".join(displayed)

func _quest_objective_text() -> String:
	if bool(quest_flags.get("trail_marker_quest_completed", false)):
		return "Quest complete: The Trail Warden has the brass plate."
	if bool(quest_flags.get("trail_marker_found", false)):
		return "Quest: Return the brass plate to the Trail Warden."
	if bool(quest_flags.get("trail_marker_search_started", false)):
		return "Quest: Search the dungeon beyond the lookout for the brass plate."
	return ""

func _inventory_status_text() -> String:
	var inventory_items := PackedStringArray()
	var healing_potions := int(inventory.get("healing_potions", 0))
	var iron_keys := int(inventory.get("iron_keys", 0))
	if healing_potions > 0:
		inventory_items.append("Healing Potions: %d" % healing_potions)
	if iron_keys > 0:
		inventory_items.append("Iron Keys: %d" % iron_keys)
	if inventory_items.is_empty():
		return ""
	return "Inventory: " + ", ".join(inventory_items)

func _restore_party_selection() -> void:
	if not get_tree().has_meta("selected_party_member"):
		return

	var selected_name := str(get_tree().get_meta("selected_party_member"))
	for party_member in get_tree().get_nodes_in_group("party_members"):
		party_member.call("set_selected", party_member.name == selected_name)

func _restore_party_health() -> void:
	var saved_party_health: Variant = get_tree().get_meta("party_health", {})
	if not saved_party_health is Dictionary:
		return

	for party_member in get_tree().get_nodes_in_group("party_members"):
		if saved_party_health.has(party_member.name):
			party_member.set_meta("health", int(saved_party_health[party_member.name]))
		party_health[party_member.name] = int(party_member.get_meta("health", MAX_PARTY_HEALTH))

func _persist_party_health() -> void:
	get_tree().set_meta("party_health", party_health.duplicate())

func debug_click_movement(message: String) -> void:
	if SWITCH_DEBUG_CLICK_AND_MOVEMENT:
		movement_debug_log.append(message)
		if movement_debug_log.size() > 100:
			movement_debug_log.remove_at(0)
		print("[click-move] ", message)

func _input(event: InputEvent) -> void:
	if event is InputEventWithModifiers:
		ctrl_down = event.ctrl_pressed
	if event is InputEventKey and command_input != null and command_input.has_focus():
		return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F2:
			_save_game()
			get_viewport().set_input_as_handled()
			return
		if event.keycode == KEY_F3:
			_load_game()
			get_viewport().set_input_as_handled()
			return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_SPACE and combat_active:
		_resolve_current_turn()
		get_viewport().set_input_as_handled()
		return

	if event is InputEventMouseMotion:
		if right_mouse_down:
			if not right_mouse_dragged and event.position.distance_to(right_mouse_press_position) >= CAMERA_DRAG_THRESHOLD:
				right_mouse_dragged = true
			if right_mouse_dragged:
				_rotate_camera(event.relative.x)
				get_viewport().set_input_as_handled()
		return

	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT:
		if event.pressed:
			if get_viewport().gui_get_hovered_control() == null:
				right_mouse_down = true
				right_mouse_dragged = false
				right_mouse_press_position = event.position
			return

		if not right_mouse_down:
			return
		right_mouse_down = false
		if right_mouse_dragged:
			right_mouse_dragged = false
			get_viewport().set_input_as_handled()
			return
		return

	if not event is InputEventMouseButton or not event.pressed:
		return
	var hovered_control := get_viewport().gui_get_hovered_control()
	if SWITCH_DEBUG_CLICK_AND_MOVEMENT and event.button_index == MOUSE_BUTTON_LEFT:
		var debug_hit := _get_mouse_hit(event.position)
		var hit_object: Variant = debug_hit.get("collider")
		var hit_name := str(hit_object.get_path()) if hit_object is Node else "none"
		var control_name := str(hovered_control.get_path()) if hovered_control != null else "none"
		debug_click_movement("click screen=%s ctrl=%s combat=%s gui=%s hit=%s world=%s selected=%s" % [event.position, event.ctrl_pressed, combat_active, control_name, hit_name, debug_hit.get("position", "none"), get_tree().get_meta("selected_party_member", "none")])
	if hovered_control != null and weapon_selector != null and (hovered_control == weapon_selector or weapon_selector.is_ancestor_of(hovered_control)):
		return
	if hovered_control != null and power_attack_selector != null and (hovered_control == power_attack_selector or power_attack_selector.is_ancestor_of(hovered_control)):
		return
	if hovered_control != null and command_panel != null and (hovered_control == command_panel or command_panel.is_ancestor_of(hovered_control)):
		return
	if hovered_control != null and action_scroll != null and hovered_control != action_scroll and action_scroll.is_ancestor_of(hovered_control):
		return
	if hovered_control != null and party_buttons != null and (hovered_control == party_buttons or party_buttons.is_ancestor_of(hovered_control)):
		return
	if hovered_control != null and combat_log_panel != null and (hovered_control == combat_log_panel or combat_log_panel.is_ancestor_of(hovered_control)):
		return
	if event.button_index in [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN]:
		if hovered_control == null:
			var zoom_direction := -1.0 if event.button_index == MOUSE_BUTTON_WHEEL_UP else 1.0
			_zoom_camera(zoom_direction * CAMERA_ZOOM_STEP)
			get_viewport().set_input_as_handled()
		return
	if hovered_control != null and (hovered_control == attack_button or hovered_control == defend_button or hovered_control == end_turn_button or hovered_control == potion_button or hovered_control == dialogue_choice_button or hovered_control == dialogue_decline_button):
		return

	var hit := _get_mouse_hit(event.position)
	if hit.is_empty():
		return

	var collider: Object = hit["collider"]
	if event.button_index == MOUSE_BUTTON_LEFT and collider is CollisionObject3D and collider.is_in_group("party_members"):
		if event.ctrl_pressed:
			if combat_active:
				_attack_party_member(collider)
		else:
			if combat_active and SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION:
				debug_click_movement("selection blocked during fixed turn: %s" % collider.name)
				get_viewport().set_input_as_handled()
				return
			if combat_active and not SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION and int(party_health.get(collider.name, 0)) <= 0:
				get_viewport().set_input_as_handled()
				return
			if combat_active and not SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION and not _is_combat_enemy(combat_turn_order[current_turn_index]) and int(party_health.get(collider.name, 0)) > 0:
				current_turn_index = combat_turn_order.find(collider.name)
				action_points = int(party_action_points.get(collider.name, 0))
			for party_member in get_tree().get_nodes_in_group("party_members"):
				party_member.call("set_selected", party_member == collider)
			get_tree().set_meta("selected_party_member", collider.name)
			debug_click_movement("selected by world click: %s" % collider.name)
			_update_combat_display()
		get_viewport().set_input_as_handled()
		return
	if event.button_index == MOUSE_BUTTON_LEFT and collider is CollisionObject3D and collider.has_meta("combat_enemy"):
		if combat_active:
			_attack_enemy(collider)
		else:
			_start_combat(collider.name)
		get_viewport().set_input_as_handled()

func _zoom_camera(size_delta: float) -> void:
	if exploration_camera == null:
		return
	exploration_camera.size = clampf(exploration_camera.size + size_delta, MIN_CAMERA_SIZE, MAX_CAMERA_SIZE)

func _rotate_camera(horizontal_delta: float) -> void:
	if exploration_camera == null:
		return
	var camera_offset := exploration_camera.global_position - CAMERA_ORBIT_TARGET
	exploration_camera.global_position = CAMERA_ORBIT_TARGET + camera_offset.rotated(Vector3.UP, horizontal_delta * CAMERA_ROTATION_SENSITIVITY)
	exploration_camera.look_at(CAMERA_ORBIT_TARGET, Vector3.UP)

func _get_mouse_hit(mouse_position: Vector2) -> Dictionary:
	var camera := get_viewport().get_camera_3d()
	if camera == null:
		return {}

	var ray_origin := camera.project_ray_origin(mouse_position)
	var ray_end := ray_origin + camera.project_ray_normal(mouse_position) * 1000.0
	var query := PhysicsRayQueryParameters3D.create(ray_origin, ray_end)
	return get_world_3d().direct_space_state.intersect_ray(query)

func _start_combat(enemy_name: String) -> void:
	if combat_active:
		return

	combat_active = true
	combat_log_text = ""
	combat_enemy_name = enemy_name
	combat_enemy_health.clear()
	var enemies := _living_combat_enemies()
	for enemy in enemies:
		combat_enemy_health[enemy.name] = int(enemy.get_meta("health", 10))
		if not enemy.is_connected("movement_finished", _on_enemy_movement_finished.bind(enemy.name)):
			enemy.connect("movement_finished", _on_enemy_movement_finished.bind(enemy.name))
	_snap_combatants_to_grid(enemies)
	if _selected_combat_enemy() == null:
		_end_combat("Combat ended")
		return
	party_health.clear()
	party_defending.clear()
	party_charge_pending.clear()
	party_charge_defending.clear()
	power_attack_penalties.clear()
	power_attack_locked.clear()
	party_action_points.clear()
	party_standard_available.clear()
	party_move_available.clear()
	party_five_foot_step_available.clear()
	combat_turn_order.clear()
	for party_member in get_tree().get_nodes_in_group("party_members"):
		party_health[party_member.name] = int(party_member.get_meta("health", 20))
		party_action_points[party_member.name] = ACTION_POINTS_PER_TURN
		party_standard_available[party_member.name] = true
		party_move_available[party_member.name] = true
		party_five_foot_step_available[party_member.name] = true
		combat_turn_order.append(party_member.name)
	_persist_party_health()
	for enemy in enemies:
		combat_turn_order.append(enemy.name)
	opportunity_remaining.clear()
	opportunity_movement_attackers.clear()
	opportunity_acted.clear()
	for actor_name in combat_turn_order:
		opportunity_remaining[actor_name] = _opportunity_limit(actor_name)
	current_turn_index = 0
	combat_round = 1
	if not _has_living_party_member():
		_end_combat("Party defeated")
		return
	if SWITCH_STANDARD_MOVE_ACTIONS and SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION:
		_roll_initiative()
	while not _is_turn_actor_alive(combat_turn_order[current_turn_index]):
		current_turn_index += 1
	_reset_turn_actions()
	_sync_party_selection_to_turn()
	_update_combat_display()
	if _is_combat_enemy(combat_turn_order[current_turn_index]):
		_enemy_take_turn()

func uses_tactical_grid() -> bool:
	return combat_active and SWITCH_STANDARD_MOVE_ACTIONS

func get_combat_movement_limit(actor_name: String) -> int:
	var speed_feet := DEFAULT_COMBAT_SPEED_FEET
	if _is_combat_enemy(actor_name):
		var enemy := get_node_or_null(actor_name)
		if enemy != null:
			speed_feet = int(enemy.get_meta("speed_feet", DEFAULT_COMBAT_SPEED_FEET))
	else:
		var character_data: Dictionary = party_character_data.get(actor_name, {})
		speed_feet = int(character_data.get("speed_feet", DEFAULT_COMBAT_SPEED_FEET))
	return maxi(1, floori(float(speed_feet) / FEET_PER_GRID_CELL))

func _load_combat_terrain() -> void:
	difficult_terrain_cell_costs.clear()
	impassable_terrain_cells.clear()
	for terrain in get_tree().get_nodes_in_group("combat_terrain"):
		if not terrain is Node3D:
			continue
		var cell := combat_grid.world_to_cell(terrain.global_position)
		var movement_cost := int(terrain.get_meta("terrain_cost", 1))
		if movement_cost > 1:
			difficult_terrain_cell_costs[cell] = movement_cost
		if bool(terrain.get_meta("terrain_impassable", false)):
			impassable_terrain_cells[cell] = true

func _has_combat_reflexes(actor_name: String) -> bool:
	if _is_combat_enemy(actor_name):
		var enemy := get_node_or_null(actor_name)
		return enemy != null and bool(enemy.get_meta("combat_reflexes", false))
	return _has_feat_effect(actor_name, "extra_opportunity_reactions")

func _opportunity_limit(actor_name: String) -> int:
	if not _has_combat_reflexes(actor_name):
		return 1
	var dexterity := 10
	if _is_combat_enemy(actor_name):
		var enemy := get_node_or_null(actor_name)
		if enemy != null:
			dexterity = int(enemy.get_meta("dexterity", 10))
	else:
		var data: Dictionary = party_character_data.get(actor_name, {})
		var attributes: Dictionary = data.get("attributes", {})
		dexterity = int(attributes.get("dexterity", 10))
	return 1 + maxi(0, floori((float(dexterity) - 10.0) / 2.0))

func begin_opportunity_movement(actor_name: String) -> void:
	if not opportunity_movement_attackers.has(actor_name):
		opportunity_movement_attackers[actor_name] = {}

func before_combat_grid_step(mover: CollisionObject3D, destination: Vector3, five_foot: bool) -> bool:
	if not uses_tactical_grid() or five_foot:
		return true
	return _resolve_opportunity_trigger(mover, true, destination)

func _resolve_opportunity_trigger(mover: CollisionObject3D, movement_trigger: bool, movement_destination: Vector3 = Vector3.ZERO) -> bool:
	if not uses_tactical_grid():
		return true
	var attackers: Array[CollisionObject3D] = []
	if _is_combat_enemy(mover.name):
		for member in get_tree().get_nodes_in_group("party_members"):
			if member is CollisionObject3D:
				attackers.append(member)
	else:
		for enemy in _living_combat_enemies():
			attackers.append(enemy)
	var already: Dictionary = opportunity_movement_attackers.get(mover.name, {}) if movement_trigger else {}
	for attacker in attackers:
		if not combat_active or not _is_turn_actor_alive(mover.name):
			return false
		if not _is_turn_actor_alive(attacker.name) or int(opportunity_remaining.get(attacker.name, 0)) <= 0 or already.has(attacker.name):
			continue
		if not bool(opportunity_acted.get(attacker.name, false)) and not _has_combat_reflexes(attacker.name):
			continue
		var mover_cell := combat_grid.world_to_cell(mover.global_position)
		var delta := combat_grid.world_to_cell(attacker.global_position) - mover_cell
		if maxi(absi(delta.x), absi(delta.y)) != 1 or not _has_clear_attack_path(attacker, mover):
			continue
		if movement_trigger:
			var destination_delta := combat_grid.world_to_cell(attacker.global_position) - combat_grid.world_to_cell(movement_destination)
			if maxi(absi(destination_delta.x), absi(destination_delta.y)) == 1:
				continue
		if movement_trigger:
			already[attacker.name] = true
			opportunity_movement_attackers[mover.name] = already
		opportunity_remaining[attacker.name] = int(opportunity_remaining[attacker.name]) - 1
		_resolve_opportunity_attack(attacker, mover)
	return combat_active and _is_turn_actor_alive(mover.name)

func _resolve_opportunity_attack(attacker: CollisionObject3D, target: CollisionObject3D) -> void:
	var enemy_attacks := _is_combat_enemy(attacker.name)
	var data: Dictionary = party_character_data.get(attacker.name, {})
	var weapon: Dictionary = party_weapon_data.get(attacker.name, {})
	if not enemy_attacks and weapon.is_empty():
		return
	var modifier := int(attacker.get_meta("attack_modifier", 0)) if enemy_attacks else _melee_attack_modifier(data) - int(power_attack_penalties.get(attacker.name, 0))
	var target_data: Dictionary = party_character_data.get(target.name, {})
	var defense := int(target.get_meta("defense", 10)) if not enemy_attacks else _party_defense(target_data) + (4 if bool(party_defending.get(target.name, false)) else 0) - (2 if bool(party_charge_defending.get(target.name, false)) else 0)
	var roll := randi_range(1, 20)
	var result := "%s opportunity attack against %s (d20 %d + %d vs defense %d)" % [_actor_display_name(attacker.name), _actor_display_name(target.name), roll, modifier, defense]
	if roll == 1 or (roll != 20 and roll + modifier < defense):
		combat_log_text = result + " misses."
		_update_combat_display()
		return
	var critical := _critical_result(roll, modifier, defense, 20 if enemy_attacks else int(weapon.get("critical_threat_min", 20)))
	var multiplier := (2 if enemy_attacks else int(weapon.get("critical_multiplier", 2))) if critical["confirmed"] else 1
	var damage := int(attacker.get_meta("attack_damage", 5)) * multiplier if enemy_attacks else _roll_weapon_damage(weapon, _melee_strength_modifier(data) + int(power_attack_penalties.get(attacker.name, 0)) * int(weapon.get("power_attack_damage_multiplier", 0)), multiplier)
	combat_log_text = result + " hits for %d damage." % damage + str(critical["text"])
	if enemy_attacks:
		party_health[target.name] = maxi(int(party_health.get(target.name, 0)) - damage, 0)
		target.set_meta("health", party_health[target.name])
		_persist_party_health()
		if int(party_health[target.name]) <= 0:
			target.call("cancel_combat_movement")
			call_deferred("_advance_combat_turn")
	else:
		combat_enemy_health[target.name] = maxi(int(combat_enemy_health.get(target.name, 0)) - damage, 0)
		target.set_meta("health", combat_enemy_health[target.name])
		if int(combat_enemy_health[target.name]) <= 0:
			quest_flags[_enemy_defeated_flag(target.name)] = true
			_persist_quest_flags()
			target.queue_free()
			if _living_combat_enemies().is_empty():
				_end_combat("All enemies defeated")
	_update_combat_display()

func _grid_navigation_map(actor: Node3D) -> RID:
	var navigation_agent := actor.get("navigation_agent") as NavigationAgent3D
	return navigation_agent.get_navigation_map() if navigation_agent != null else RID()

func _grid_occupied_cells(excluded_actor: CollisionObject3D) -> Dictionary:
	var occupied: Dictionary = {}
	for member in get_tree().get_nodes_in_group("party_members"):
		if member != excluded_actor and member is CollisionObject3D:
			occupied[combat_grid.world_to_cell(member.global_position)] = member
	for enemy in _living_combat_enemies():
		if enemy != excluded_actor:
			occupied[combat_grid.world_to_cell(enemy.global_position)] = enemy
	return occupied

func _snap_combatants_to_grid(enemies: Array[CollisionObject3D]) -> void:
	if not SWITCH_STANDARD_MOVE_ACTIONS or enemies.is_empty():
		return
	var occupied: Dictionary = {}
	var combatants: Array[CollisionObject3D] = []
	for member in get_tree().get_nodes_in_group("party_members"):
		if member is CollisionObject3D:
			combatants.append(member)
	combatants.append_array(enemies)
	for actor in combatants:
		var navigation_map := _grid_navigation_map(actor)
		if NavigationServer3D.map_get_iteration_id(navigation_map) == 0:
			continue
		var excluded: Array[RID] = [actor.get_rid()]
		var cell := combat_grid.find_nearest_open_cell(navigation_map, get_world_3d(), combat_grid.world_to_cell(actor.global_position), occupied, excluded)
		actor.global_position = combat_grid.cell_to_world(cell, actor.global_position.y)
		occupied[cell] = actor

func get_combat_grid_route(actor: CollisionObject3D, destination: Vector3) -> Dictionary:
	if not uses_tactical_grid():
		return {}
	var navigation_map := _grid_navigation_map(actor)
	if NavigationServer3D.map_get_iteration_id(navigation_map) == 0:
		return {}
	var excluded: Array[RID] = [actor.get_rid()]
	var occupied := _grid_occupied_cells(actor)
	var start := combat_grid.world_to_cell(actor.global_position)
	var desired := combat_grid.world_to_cell(destination)
	if impassable_terrain_cells.has(desired):
		return {}
	var goal := combat_grid.find_nearest_open_cell(navigation_map, get_world_3d(), desired, occupied, excluded)
	var route := combat_grid.find_path(navigation_map, get_world_3d(), start, goal, occupied, excluded, 0, difficult_terrain_cell_costs, impassable_terrain_cells)
	if not route.is_empty():
		route["step_costs"] = combat_grid.path_step_costs(route["path"], 0, difficult_terrain_cell_costs)
	return route

func get_combat_grid_approach_route(actor: CollisionObject3D, target: CollisionObject3D) -> Dictionary:
	if not uses_tactical_grid():
		return {}
	var navigation_map := _grid_navigation_map(actor)
	if NavigationServer3D.map_get_iteration_id(navigation_map) == 0:
		return {}
	var excluded: Array[RID] = [actor.get_rid()]
	var occupied := _grid_occupied_cells(actor)
	var start := combat_grid.world_to_cell(actor.global_position)
	var target_cell := combat_grid.world_to_cell(target.global_position)
	var best: Dictionary = {}
	for offset in [Vector2i(-1, -1), Vector2i(0, -1), Vector2i(1, -1), Vector2i(-1, 0), Vector2i(1, 0), Vector2i(-1, 1), Vector2i(0, 1), Vector2i(1, 1)]:
		var candidate: Vector2i = target_cell + offset
		var route := combat_grid.find_path(navigation_map, get_world_3d(), start, candidate, occupied, excluded, 0, difficult_terrain_cell_costs, impassable_terrain_cells)
		if not route.is_empty() and (best.is_empty() or int(route["cost"]) < int(best["cost"])):
			route["step_costs"] = combat_grid.path_step_costs(route["path"], 0, difficult_terrain_cell_costs)
			best = route
	return best

func _initiative_before(first: Dictionary, second: Dictionary) -> bool:
	if first["alive"] != second["alive"]:
		return first["alive"]
	if first["total"] != second["total"]:
		return first["total"] > second["total"]
	if first["modifier"] != second["modifier"]:
		return first["modifier"] > second["modifier"]
	var first_ties: Array = first["tie_rolls"]
	var second_ties: Array = second["tie_rolls"]
	for index in range(mini(first_ties.size(), second_ties.size())):
		if first_ties[index] != second_ties[index]:
			return first_ties[index] > second_ties[index]
	return first["original_index"] < second["original_index"]

func _roll_initiative() -> void:
	var records: Array[Dictionary] = []
	for index in range(combat_turn_order.size()):
		var actor_name := combat_turn_order[index]
		var alive := _is_turn_actor_alive(actor_name)
		var modifier := 0
		if not _is_combat_enemy(actor_name):
			var data: Dictionary = party_character_data.get(actor_name, {})
			var attributes: Dictionary = data.get("attributes", {})
			modifier = floori((float(attributes.get("dexterity", 10)) - 10.0) / 2.0)
		var roll := randi_range(1, 20) if alive else 0
		records.append({"name": actor_name, "alive": alive, "roll": roll, "modifier": modifier, "total": roll + modifier if alive else 0, "tie_rolls": [], "original_index": index})
		if alive:
			_append_shared_text("%s initiative: d20 %d + %d = %d" % [_actor_display_name(actor_name), roll, modifier, roll + modifier])
	var tied := true
	while tied:
		tied = false
		var tie_groups: Dictionary = {}
		for record in records:
			if not record["alive"]:
				continue
			var key := "%d:%d:%s" % [record["total"], record["modifier"], str(record["tie_rolls"])]
			if not tie_groups.has(key):
				tie_groups[key] = []
			tie_groups[key].append(record)
		for group in tie_groups.values():
			if group.size() > 1:
				tied = true
				for record in group:
					record["tie_rolls"].append(randi_range(1, 20))
	records.sort_custom(_initiative_before)
	combat_turn_order.clear()
	for record in records:
		combat_turn_order.append(record["name"])

func _attack_current_enemy() -> void:
	if not combat_active or combat_turn_order.is_empty() or not is_party_member_turn(combat_turn_order[current_turn_index]):
		return
	var enemy := _selected_combat_enemy()
	if enemy != null:
		_attack_enemy(enemy)

func _charge_current_enemy() -> void:
	if combat_turn_order.is_empty():
		return
	var actor_name := combat_turn_order[current_turn_index]
	var enemy := _selected_combat_enemy()
	if not SWITCH_STANDARD_MOVE_ACTIONS or enemy == null or enemy.is_queued_for_deletion() or not is_party_member_turn(actor_name) or not _standard_available(actor_name) or not bool(party_move_available.get(actor_name, false)) or not bool(party_five_foot_step_available.get(actor_name, false)):
		return
	var actor := get_node_or_null(actor_name) as CollisionObject3D
	if actor == null or _actor_is_moving(actor) or actor.global_position.distance_to(enemy.global_position) <= MELEE_ATTACK_RANGE:
		return
	var route := get_combat_grid_approach_route(actor, enemy)
	if route.is_empty() or int(route.get("cost", 0)) > get_combat_movement_limit(actor_name) * 2 or (route["path"] as PackedVector3Array).size() < 2:
		combat_log_text = "Cannot reach the enemy with a charge."
		_update_combat_display()
		return
	if actor.call("move_towards_enemy", enemy):
		party_charge_pending[actor_name] = true
		combat_log_text = "%s charges toward %s." % [_actor_display_name(actor_name), _actor_display_name(enemy.name)]
	else:
		combat_log_text = "Cannot find a route to the enemy."
	_update_combat_display()

func _full_attack_count(actor_name: String) -> int:
	var character_data: Dictionary = party_character_data.get(actor_name, {})
	var base_attack_bonus := int(character_data.get("base_attack_bonus", 0))
	return 1 + maxi(0, floori((float(base_attack_bonus) - 1.0) / 5.0))

func _can_full_attack(actor_name: String) -> bool:
	if not SWITCH_STANDARD_MOVE_ACTIONS or _full_attack_count(actor_name) < 2:
		return false
	if not is_party_member_turn(actor_name) or not _standard_available(actor_name) or not bool(party_move_available.get(actor_name, false)):
		return false
	var actor := get_node_or_null(actor_name) as CollisionObject3D
	return actor != null and not _actor_is_moving(actor)

func _full_attack_current_enemy() -> void:
	if combat_turn_order.is_empty():
		return
	var actor_name := combat_turn_order[current_turn_index]
	var enemy := _selected_combat_enemy()
	if enemy == null or not _can_full_attack(actor_name):
		return
	var actor := get_node_or_null(actor_name) as CollisionObject3D
	if actor == null or actor.global_position.distance_to(enemy.global_position) > MELEE_ATTACK_RANGE or not _has_clear_attack_path(actor, enemy):
		combat_log_text = "%s must be adjacent to make a full attack." % _actor_display_name(actor_name)
		_update_combat_display()
		return
	var attack_count := _full_attack_count(actor_name)
	for attack_index in range(attack_count):
		if not combat_active or enemy.is_queued_for_deletion() or not _is_combat_enemy(enemy.name):
			break
		_attack_enemy(enemy, actor_name, attack_index, false)
	if combat_active and is_party_member_turn(actor_name):
		_consume_full_round_action(actor_name)

func cancel_pending_charge(character_name: String) -> void:
	party_charge_pending.erase(character_name)

func _melee_strength_modifier(character_data: Dictionary) -> int:
	var attributes: Dictionary = character_data.get("attributes", {})
	return floori((float(attributes.get("strength", 10)) - 10.0) / 2.0)

func _melee_attack_modifier(character_data: Dictionary) -> int:
	var attributes: Dictionary = character_data.get("attributes", {})
	if character_data.has("base_attack_bonus") and attributes.has("strength"):
		return int(character_data["base_attack_bonus"]) + _melee_strength_modifier(character_data)
	return int(character_data.get("attack_modifier", 0))

func _party_defense(character_data: Dictionary) -> int:
	var attributes: Dictionary = character_data.get("attributes", {})
	if attributes.has("dexterity"):
		return 10 + floori((float(attributes["dexterity"]) - 10.0) / 2.0)
	return int(character_data.get("defense", 10))

func _roll_weapon_damage(weapon: Dictionary, bonus: int, multiplier: int) -> int:
	var damage := 0
	for _die in range(int(weapon["damage_dice_count"]) * multiplier):
		damage += randi_range(1, int(weapon["damage_die_sides"]))
	return maxi(0, damage + bonus * multiplier)

func _critical_result(roll: int, modifier: int, defense: int, threat_min: int) -> Dictionary:
	if roll < threat_min:
		return {"confirmed": false, "text": ""}
	var confirmation := randi_range(1, 20)
	var confirmed := confirmation == 20 or (confirmation != 1 and confirmation + modifier >= defense)
	var result := "confirmed" if confirmed else "not confirmed"
	return {"confirmed": confirmed, "text": " Critical %s (d20 %d + %d vs defense %d)." % [result, confirmation, modifier, defense]}

func _attack_enemy(enemy: CollisionObject3D, acting_character: String = "", iterative_attack_index: int = 0, consume_action: bool = true) -> void:
	if combat_turn_order.is_empty():
		return

	var active_actor_name := combat_turn_order[current_turn_index] if acting_character.is_empty() else acting_character
	var active_party_member: CollisionObject3D
	for party_member in get_tree().get_nodes_in_group("party_members"):
		if party_member.name == active_actor_name:
			active_party_member = party_member
			break
	if active_party_member == null or not _is_combat_enemy(enemy.name) or not can_continue_party_movement(active_actor_name):
		return
	combat_enemy_name = enemy.name
	if _actor_is_moving(active_party_member) or not _standard_available(active_actor_name):
		return

	if active_party_member.global_position.distance_to(enemy.global_position) > MELEE_ATTACK_RANGE:
		if SWITCH_MOVE_CHARACTER_TOWARDS_ENEMY_ALWAYS and can_party_move(active_actor_name):
			if active_party_member.call("move_towards_enemy", enemy):
				combat_log_text = "%s moves toward %s." % [_actor_display_name(active_actor_name), _actor_display_name(enemy.name)]
			else:
				combat_log_text = "Cannot find a route to the enemy."
			_update_combat_display()
			return
		combat_log_text = "%s is too far away. Move within 2 units to attack." % _actor_display_name(active_actor_name)
		_update_combat_display()
		return
	if _party_points(active_actor_name) <= 0:
		return

	if not _has_clear_attack_path(active_party_member, enemy):
		combat_log_text = "The attack is blocked."
		_update_combat_display()
		return

	var attacker_data: Dictionary = party_character_data.get(active_actor_name, {})
	var weapon_data: Dictionary = party_weapon_data.get(active_actor_name, {})
	if weapon_data.is_empty():
		combat_log_text = "%s has no valid equipped weapon." % _actor_display_name(active_actor_name)
		_update_combat_display()
		return
	var roll := randi_range(1, 20)
	var penalty := _lock_power_attack(active_actor_name)
	var charging := bool(party_charge_pending.get(active_actor_name, false))
	var party_attack_modifier := _melee_attack_modifier(attacker_data) - penalty - 5 * iterative_attack_index + (2 if charging else 0)
	var defense := int(enemy.get_meta("defense", 10))
	var roll_text := "(d20 %d + %d vs defense %d)" % [roll, party_attack_modifier, defense]
	if roll == 1 or (roll != 20 and roll + party_attack_modifier < defense):
		combat_log_text = "%s misses %s %s." % [_actor_display_name(active_actor_name), _actor_display_name(enemy.name), roll_text]
		if consume_action:
			_consume_charge_action(active_actor_name) if charging else _consume_main_action(active_actor_name)
		return
	var critical := _critical_result(roll, party_attack_modifier, defense, int(weapon_data.get("critical_threat_min", 20)))
	var multiplier := int(weapon_data.get("critical_multiplier", 2)) if critical["confirmed"] else 1
	var bonus := _melee_strength_modifier(attacker_data) + penalty * int(weapon_data.get("power_attack_damage_multiplier", 0))
	var party_attack_damage := _roll_weapon_damage(weapon_data, bonus, multiplier)
	combat_enemy_health[enemy.name] = maxi(int(combat_enemy_health.get(enemy.name, 0)) - party_attack_damage, 0)
	enemy.set_meta("health", combat_enemy_health[enemy.name])
	combat_log_text = "%s hits %s for %d damage %s." % [_actor_display_name(active_actor_name), _actor_display_name(enemy.name), party_attack_damage, roll_text]
	if not str(critical["text"]).is_empty():
		combat_log_text += str(critical["text"])
	if int(combat_enemy_health[enemy.name]) == 0:
		quest_flags[_enemy_defeated_flag(enemy.name)] = true
		_persist_quest_flags()
		enemy.queue_free()
		if _living_combat_enemies().is_empty():
			_end_combat("All enemies defeated")
		else:
			combat_enemy_name = _living_combat_enemies()[0].name
			if consume_action:
				_consume_charge_action(active_actor_name) if charging else _consume_main_action(active_actor_name)
		return

	if consume_action:
		_consume_charge_action(active_actor_name) if charging else _consume_main_action(active_actor_name)

func _has_clear_attack_path(attacker: CollisionObject3D, target: CollisionObject3D) -> bool:
	var start := attacker.global_position + Vector3.UP * 0.6
	var end := target.global_position + Vector3.UP * 0.6
	var query := PhysicsRayQueryParameters3D.create(start, end)
	query.exclude = [attacker.get_rid(), target.get_rid()]
	return get_world_3d().direct_space_state.intersect_ray(query).is_empty()

func _attack_party_member(target: CollisionObject3D) -> void:
	var actor := _current_potion_user() as CollisionObject3D
	if actor == null or actor == target or action_points <= 0 or not _standard_available(actor.name) or _actor_is_moving(actor) or _current_party_health(target) <= 0:
		return
	if actor.global_position.distance_to(target.global_position) > MELEE_ATTACK_RANGE:
		combat_log_text = "%s is too far away to attack." % _actor_display_name(target.name)
		_update_combat_display()
		return
	if not _has_clear_attack_path(actor, target):
		combat_log_text = "The attack is blocked."
		_update_combat_display()
		return
	var weapon: Dictionary = party_weapon_data.get(actor.name, {})
	if weapon.is_empty():
		return
	var attacker: Dictionary = party_character_data.get(actor.name, {})
	var defender: Dictionary = party_character_data.get(target.name, {})
	var roll := randi_range(1, 20)
	var penalty := _lock_power_attack(actor.name)
	var modifier := _melee_attack_modifier(attacker) - penalty
	var defense := _party_defense(defender) + (4 if SWITCH_STANDARD_MOVE_ACTIONS and bool(party_defending.get(target.name, false)) else 0) - (2 if bool(party_charge_defending.get(target.name, false)) else 0)
	if roll == 1 or (roll != 20 and roll + modifier < defense):
		combat_log_text = "%s misses %s (d20 %d + %d vs defense %d)." % [_actor_display_name(actor.name), _actor_display_name(target.name), roll, modifier, defense]
	else:
		var critical := _critical_result(roll, modifier, defense, int(weapon.get("critical_threat_min", 20)))
		var multiplier := int(weapon.get("critical_multiplier", 2)) if critical["confirmed"] else 1
		var bonus := _melee_strength_modifier(attacker) + penalty * int(weapon.get("power_attack_damage_multiplier", 0))
		var damage := _roll_weapon_damage(weapon, bonus, multiplier)
		if not SWITCH_STANDARD_MOVE_ACTIONS and bool(party_defending.get(target.name, false)):
			var enemy := _selected_combat_enemy()
			damage = mini(damage, int(enemy.get_meta("defended_attack_damage", 2)) if enemy != null else 2)
			party_defending.erase(target.name)
			target.call("set_defending", false)
		var health := maxi(_current_party_health(target) - damage, 0)
		party_health[target.name] = health
		target.set_meta("health", health)
		_persist_party_health()
		combat_log_text = "%s hits %s for %d damage (d20 %d + %d vs defense %d)." % [_actor_display_name(actor.name), _actor_display_name(target.name), damage, roll, modifier, defense]
		if not str(critical["text"]).is_empty():
			combat_log_text += str(critical["text"])
	_consume_main_action()

func _resolve_current_turn() -> void:
	if combat_turn_order.is_empty():
		return
	if not _is_combat_enemy(combat_turn_order[current_turn_index]):
		var actor := get_node_or_null(combat_turn_order[current_turn_index])
		if actor != null and bool(party_charge_pending.get(actor.name, false)):
			actor.call("cancel_combat_movement")
	if enemy_turn_in_progress:
		var enemy := get_node_or_null(_current_enemy_turn_name())
		if enemy != null:
			combat_log_text = "%s ends its move." % _actor_display_name(enemy.name)
			enemy_move_cancelled = true
			enemy.call("cancel_movement")
		else:
			_end_combat("Combat ended")
		return

	if _is_combat_enemy(combat_turn_order[current_turn_index]):
		_enemy_take_turn()
	elif not SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION:
		if SWITCH_STANDARD_MOVE_ACTIONS:
			party_standard_available[combat_turn_order[current_turn_index]] = false
			party_move_available[combat_turn_order[current_turn_index]] = false
		party_action_points[combat_turn_order[current_turn_index]] = 0
		action_points = 0
		_advance_shared_party_actor_or_enemy()
	else:
		_advance_combat_turn()

func _advance_shared_party_actor_or_enemy() -> void:
	for offset in range(1, combat_turn_order.size()):
		var next_index := (current_turn_index + offset) % combat_turn_order.size()
		var next_actor_name := combat_turn_order[next_index]
		if not _is_combat_enemy(next_actor_name) and _is_turn_actor_alive(next_actor_name) and _party_points(next_actor_name) > 0:
			current_turn_index = next_index
			action_points = _party_points(next_actor_name)
			_sync_party_selection_to_turn()
			_update_combat_display()
			return
	_advance_combat_turn()

func _advance_combat_turn() -> void:
	if combat_turn_order.is_empty():
		return

	if not _has_living_party_member():
		_end_combat("Party defeated")
		return
	if not SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION:
		if _is_combat_enemy(combat_turn_order[current_turn_index]):
			for next_index in range(current_turn_index + 1, combat_turn_order.size()):
				var next_actor_name := combat_turn_order[next_index]
				if _is_combat_enemy(next_actor_name) and _is_turn_actor_alive(next_actor_name):
					current_turn_index = next_index
					_reset_turn_actions()
					_sync_party_selection_to_turn()
					_update_combat_display()
					_enemy_take_turn()
					return
			combat_round += 1
			opportunity_movement_attackers.clear()
			power_attack_penalties.clear()
			power_attack_locked.clear()
			for member_name in party_action_points:
				opportunity_acted[member_name] = true
				opportunity_remaining[member_name] = _opportunity_limit(member_name)
				party_action_points[member_name] = ACTION_POINTS_PER_TURN
				if SWITCH_STANDARD_MOVE_ACTIONS:
					party_standard_available[member_name] = true
					party_move_available[member_name] = true
					party_charge_defending.erase(member_name)
					party_defending.erase(member_name)
					var actor := get_node_or_null(member_name)
					if actor != null:
						actor.call("set_defending", false)
			for index in range(combat_turn_order.size()):
				if not _is_combat_enemy(combat_turn_order[index]) and _is_turn_actor_alive(combat_turn_order[index]):
					current_turn_index = index
					break
			action_points = int(party_action_points.get(combat_turn_order[current_turn_index], 0))
			_sync_party_selection_to_turn()
			_update_combat_display()
		else:
			for party_member in get_tree().get_nodes_in_group("party_members"):
				party_member.call("cancel_combat_movement")
			for index in range(combat_turn_order.size()):
				if _is_combat_enemy(combat_turn_order[index]) and _is_turn_actor_alive(combat_turn_order[index]):
					current_turn_index = index
					break
			_reset_turn_actions()
			_sync_party_selection_to_turn()
			_update_combat_display()
			_enemy_take_turn()
		return

	for _step in range(combat_turn_order.size()):
		current_turn_index += 1
		if current_turn_index >= combat_turn_order.size():
			current_turn_index = 0
			combat_round += 1
		if _is_turn_actor_alive(combat_turn_order[current_turn_index]):
			power_attack_penalties.erase(combat_turn_order[current_turn_index])
			power_attack_locked.erase(combat_turn_order[current_turn_index])
			_reset_turn_actions()
			_sync_party_selection_to_turn()
			_update_combat_display()
			if _is_combat_enemy(combat_turn_order[current_turn_index]):
				_enemy_take_turn()
			return

	_end_combat("Party defeated")

func _enemy_take_turn() -> void:
	if action_points <= 0:
		_advance_combat_turn()
		return
	var enemy_name := _current_enemy_turn_name()
	var enemy := get_node_or_null(enemy_name) as CollisionObject3D
	if enemy == null:
		_end_combat("Combat ended")
		return

	var nearest_member: CollisionObject3D
	var nearest_distance := INF
	for party_member in get_tree().get_nodes_in_group("party_members"):
		if int(party_health.get(party_member.name, 0)) <= 0:
			continue
		var distance := enemy.global_position.distance_squared_to(party_member.global_position)
		if distance < nearest_distance:
			nearest_distance = distance
			nearest_member = party_member

	if nearest_member == null:
		_end_combat("Party defeated")
		return

	if enemy.global_position.distance_to(nearest_member.global_position) > MELEE_ATTACK_RANGE or not _has_clear_attack_path(enemy, nearest_member):
		if SWITCH_STANDARD_MOVE_ACTIONS:
			if bool(enemy_move_available.get(enemy_name, true)):
				enemy_move_available[enemy_name] = false
			else:
				enemy_standard_available[enemy_name] = false
		action_points -= 1
		enemy_move_cancelled = false
		enemy_turn_in_progress = true
		combat_log_text = "%s moves toward %s." % [_actor_display_name(enemy_name), _actor_display_name(nearest_member.name)]
		_update_combat_display()
		enemy.call("move_toward_target", nearest_member, MELEE_ATTACK_RANGE - 0.5)
		return

	if SWITCH_STANDARD_MOVE_ACTIONS and not bool(enemy_standard_available.get(enemy_name, true)):
		_advance_combat_turn()
		return
	if SWITCH_STANDARD_MOVE_ACTIONS:
		enemy_standard_available[enemy_name] = false
	action_points -= 1
	var roll := randi_range(1, 20)
	var attack_modifier := int(enemy.get_meta("attack_modifier", 0))
	var target_data: Dictionary = party_character_data.get(nearest_member.name, {})
	var party_defense := _party_defense(target_data) + (4 if SWITCH_STANDARD_MOVE_ACTIONS and bool(party_defending.get(nearest_member.name, false)) else 0) - (2 if bool(party_charge_defending.get(nearest_member.name, false)) else 0)
	var roll_text := "(d20 %d + %d vs defense %d)" % [roll, attack_modifier, party_defense]
	if roll == 1 or (roll != 20 and roll + attack_modifier < party_defense):
		combat_log_text = "%s misses %s %s." % [_actor_display_name(enemy_name), _actor_display_name(nearest_member.name), roll_text]
		_update_combat_display()
		_enemy_take_turn()
		return
	var damage := int(enemy.get_meta("attack_damage", 5))
	var critical := _critical_result(roll, attack_modifier, party_defense, 20)
	if critical["confirmed"]:
		damage *= 2
	if not SWITCH_STANDARD_MOVE_ACTIONS and bool(party_defending.get(nearest_member.name, false)):
		damage = int(enemy.get_meta("defended_attack_damage", 2))
		party_defending.erase(nearest_member.name)
		nearest_member.call("set_defending", false)
	var remaining_health: int = max(int(party_health[nearest_member.name]) - damage, 0)
	party_health[nearest_member.name] = remaining_health
	nearest_member.set_meta("health", remaining_health)
	_persist_party_health()
	combat_log_text = "%s hits %s for %d damage %s." % [_actor_display_name(enemy_name), _actor_display_name(nearest_member.name), damage, roll_text]
	if not str(critical["text"]).is_empty():
		combat_log_text += str(critical["text"])
	if remaining_health == 0:
		combat_log_text += " %s is down." % _actor_display_name(nearest_member.name)
	_update_combat_display()
	_enemy_take_turn()

func _on_enemy_movement_finished(approach_found: bool, enemy_name: String) -> void:
	if not enemy_turn_in_progress:
		return

	if not approach_found:
		combat_log_text = "%s cannot find a clear approach." % _actor_display_name(enemy_name)
	enemy_turn_in_progress = false
	if combat_active:
		if approach_found and not enemy_move_cancelled:
			_enemy_take_turn()
		else:
			_advance_combat_turn()

func _is_turn_actor_alive(actor_name: String) -> bool:
	if _is_combat_enemy(actor_name):
		return int(combat_enemy_health.get(actor_name, 0)) > 0
	return int(party_health.get(actor_name, 0)) > 0

func _has_living_party_member() -> bool:
	for party_member in get_tree().get_nodes_in_group("party_members"):
		if int(party_health.get(party_member.name, 0)) > 0:
			return true
	return false

func _actor_display_name(actor_name: String) -> String:
	if _is_combat_enemy(actor_name):
		return actor_name
	for party_member in get_tree().get_nodes_in_group("party_members"):
		if party_member.name == actor_name:
			var name_label := party_member.get_node_or_null("NameLabel") as Label3D
			if name_label != null and not name_label.text.is_empty():
				return name_label.text
	return actor_name

func _party_weapon_name(actor_name: String) -> String:
	var weapon_data: Dictionary = party_weapon_data.get(actor_name, {})
	return str(weapon_data.get("display_name", "Unavailable"))

func _end_combat(result: String) -> void:
	combat_active = false
	enemy_turn_in_progress = false
	party_defending.clear()
	party_charge_pending.clear()
	party_charge_defending.clear()
	for party_member in get_tree().get_nodes_in_group("party_members"):
		party_member.call("set_defending", false)
	combat_turn_order.clear()
	_select_fallback_party_member()
	_append_shared_text(result)
	_append_shared_text("Exploration")
	_update_combat_display()

func _select_fallback_party_member() -> void:
	var members := get_tree().get_nodes_in_group("party_members")
	var selected: Node = null
	for member in members:
		if bool(member.get("is_selected")) and int(member.get_meta("health", MAX_PARTY_HEALTH)) > 0:
			selected = member
			break
	if selected == null:
		for member in members:
			if int(member.get_meta("health", MAX_PARTY_HEALTH)) > 0:
				selected = member
				break
	if selected == null and not members.is_empty():
		selected = members[0]
	for member in members:
		member.call("set_selected", member == selected)
	if selected != null:
		get_tree().set_meta("selected_party_member", selected.name)

func _sync_party_selection_to_turn() -> void:
	var active_actor_name := combat_turn_order[current_turn_index]
	for party_member in get_tree().get_nodes_in_group("party_members"):
		party_member.call("set_selected", party_member.name == active_actor_name)

func is_party_member_turn(character_name: String) -> bool:
	return combat_active and not combat_turn_order.is_empty() and combat_turn_order[current_turn_index] == character_name and int(party_health.get(character_name, 0)) > 0

func _standard_available(character_name: String) -> bool:
	if not SWITCH_STANDARD_MOVE_ACTIONS:
		return _party_points(character_name) > 0
	return bool(party_standard_available.get(character_name, false))

func _sync_budget_points(character_name: String) -> void:
	var points := int(bool(party_standard_available.get(character_name, false))) + int(bool(party_move_available.get(character_name, false)))
	party_action_points[character_name] = points
	if not combat_turn_order.is_empty() and combat_turn_order[current_turn_index] == character_name:
		action_points = points

func _party_points(character_name: String) -> int:
	if SWITCH_STANDARD_MOVE_ACTIONS:
		return int(party_action_points.get(character_name, 0))
	if SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION:
		return action_points if is_party_member_turn(character_name) else 0
	return int(party_action_points.get(character_name, 0))

func can_continue_party_movement(character_name: String) -> bool:
	if SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION:
		return is_party_member_turn(character_name) and action_points > 0
	return combat_active and not combat_turn_order.is_empty() and not _is_combat_enemy(combat_turn_order[current_turn_index]) and int(party_health.get(character_name, 0)) > 0 and _party_points(character_name) > 0

func _spend_party_point(character_name: String) -> void:
	if SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION:
		action_points -= 1
	else:
		party_action_points[character_name] = maxi(_party_points(character_name) - 1, 0)
		if combat_turn_order[current_turn_index] == character_name:
			action_points = int(party_action_points[character_name])

func _reset_turn_actions() -> void:
	action_points = ACTION_POINTS_PER_TURN
	if not combat_turn_order.is_empty():
		var opportunity_actor := combat_turn_order[current_turn_index]
		opportunity_acted[opportunity_actor] = true
		opportunity_remaining[opportunity_actor] = _opportunity_limit(opportunity_actor)
		opportunity_movement_attackers.erase(opportunity_actor)
	if SWITCH_STANDARD_MOVE_ACTIONS and not combat_turn_order.is_empty():
		var actor_name := combat_turn_order[current_turn_index]
		if _is_combat_enemy(actor_name):
			enemy_standard_available[actor_name] = true
			enemy_move_available[actor_name] = true
		else:
			party_standard_available[actor_name] = true
			party_move_available[actor_name] = true
			party_five_foot_step_available[actor_name] = true
			party_charge_defending.erase(actor_name)
			_sync_budget_points(actor_name)
			party_defending.erase(actor_name)
			var actor := get_node_or_null(actor_name)
			if actor != null:
				actor.call("set_defending", false)

func can_party_move(character_name: String) -> bool:
	return is_party_member_turn(character_name) and _party_points(character_name) > 0 and (not SWITCH_STANDARD_MOVE_ACTIONS or bool(party_five_foot_step_available.get(character_name, false)))

func can_begin_five_foot_step(character_name: String) -> bool:
	var actor := get_node_or_null(character_name)
	return SWITCH_STANDARD_MOVE_ACTIONS and is_party_member_turn(character_name) and bool(party_five_foot_step_available.get(character_name, false)) and actor != null and not _actor_is_moving(actor)

func can_begin_withdraw(character_name: String) -> bool:
	var actor := get_node_or_null(character_name)
	return SWITCH_STANDARD_MOVE_ACTIONS and is_party_member_turn(character_name) and _standard_available(character_name) and bool(party_move_available.get(character_name, false)) and bool(party_five_foot_step_available.get(character_name, false)) and actor != null and not _actor_is_moving(actor)

func _begin_withdraw() -> void:
	if combat_turn_order.is_empty():
		return
	var actor_name := combat_turn_order[current_turn_index]
	if can_begin_withdraw(actor_name):
		get_node_or_null(actor_name).call("begin_withdraw")
		_append_shared_text("%s selects Withdraw." % _actor_display_name(actor_name))

func finish_withdraw(character_name: String, moved: bool) -> void:
	if not moved or not is_party_member_turn(character_name):
		return
	party_standard_available[character_name] = false
	party_move_available[character_name] = false
	party_five_foot_step_available[character_name] = false
	_sync_budget_points(character_name)
	_append_shared_text("%s withdraws." % _actor_display_name(character_name))
	_finish_action_or_update()

func _begin_five_foot_step() -> void:
	if combat_turn_order.is_empty():
		return
	var actor_name := combat_turn_order[current_turn_index]
	if can_begin_five_foot_step(actor_name):
		get_node_or_null(actor_name).call("begin_five_foot_step")
		_append_shared_text("%s selects a 5-foot step." % _actor_display_name(actor_name))

func finish_five_foot_step(character_name: String) -> void:
	if can_begin_five_foot_step(character_name):
		party_five_foot_step_available[character_name] = false
		_append_shared_text("%s takes a 5-foot step." % _actor_display_name(character_name))
		_update_combat_display()

func finish_party_movement(character_name: String, spent: bool) -> void:
	if not can_continue_party_movement(character_name):
		return
	if bool(party_charge_pending.get(character_name, false)):
		return
	if spent:
		party_five_foot_step_available[character_name] = false
		if SWITCH_STANDARD_MOVE_ACTIONS:
			if bool(party_move_available.get(character_name, false)):
				party_move_available[character_name] = false
			else:
				party_standard_available[character_name] = false
			_sync_budget_points(character_name)
		else:
			_spend_party_point(character_name)
		_append_action_usage(character_name)
	_finish_action_or_update()

func finish_enemy_approach(character_name: String, enemy: CollisionObject3D) -> void:
	var charging := bool(party_charge_pending.get(character_name, false))
	if is_instance_valid(enemy) and not enemy.is_queued_for_deletion() and can_continue_party_movement(character_name):
		if _is_combat_enemy(enemy.name):
			var actor := get_node_or_null(character_name) as Node3D
			if actor != null and actor.global_position.distance_to(enemy.global_position) <= MELEE_ATTACK_RANGE:
				_attack_enemy(enemy, character_name)
			else:
				combat_log_text = "%s is too far away to attack." % _actor_display_name(character_name)
				_update_combat_display()
	if charging and party_charge_pending.has(character_name):
		party_charge_pending.erase(character_name)
		if is_party_member_turn(character_name):
			combat_log_text = "Charge could not reach or attack the enemy."
			_consume_main_action(character_name)

func _consume_main_action(character_name: String = "") -> void:
	if character_name.is_empty():
		character_name = combat_turn_order[current_turn_index]
	if SWITCH_STANDARD_MOVE_ACTIONS:
		party_standard_available[character_name] = false
		_sync_budget_points(character_name)
	else:
		_spend_party_point(character_name)
	_append_action_usage(character_name)
	_finish_action_or_update()

func _consume_charge_action(character_name: String) -> void:
	party_charge_pending.erase(character_name)
	party_charge_defending[character_name] = true
	party_standard_available[character_name] = false
	party_move_available[character_name] = false
	party_five_foot_step_available[character_name] = false
	_sync_budget_points(character_name)
	_append_shared_text("%s charges: +2 attack, -2 defense until their next turn." % _actor_display_name(character_name))
	_finish_action_or_update()

func _consume_full_round_action(character_name: String) -> void:
	party_standard_available[character_name] = false
	party_move_available[character_name] = false
	party_five_foot_step_available[character_name] = false
	_sync_budget_points(character_name)
	_append_action_usage(character_name)
	_finish_action_or_update()

func _finish_action_or_update() -> void:
	if not SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION:
		if not SWITCH_TURN_END_PRESSED_AUTOMATICALLY_IF_NO_ACTION_POINTS_LEFT:
			_update_combat_display()
			return
		if _party_points(combat_turn_order[current_turn_index]) <= 0:
			_advance_shared_party_actor_or_enemy()
		else:
			_update_combat_display()
		return
	if action_points <= 0:
		if SWITCH_TURN_END_PRESSED_AUTOMATICALLY_IF_NO_ACTION_POINTS_LEFT:
			_advance_combat_turn()
		else:
			_update_combat_display()
	else:
		_update_combat_display()

func _defend_current_actor() -> void:
	if combat_turn_order.is_empty():
		return

	var active_actor_name := combat_turn_order[current_turn_index]
	if not is_party_member_turn(active_actor_name) or action_points <= 0 or not _standard_available(active_actor_name):
		return
	var actor := _current_potion_user()
	if actor == null or _actor_is_moving(actor):
		return

	party_defending[active_actor_name] = true
	for party_member in get_tree().get_nodes_in_group("party_members"):
		if party_member.name == active_actor_name:
			party_member.call("set_defending", true)
			break
	var enemy := _selected_combat_enemy()
	var defended_damage := int(enemy.get_meta("defended_attack_damage", 2)) if enemy != null else 2
	combat_log_text = "%s takes total defense (+4 defense until their next turn)." % _actor_display_name(active_actor_name) if SWITCH_STANDARD_MOVE_ACTIONS else "%s braces; the next hit against them deals %d damage." % [_actor_display_name(active_actor_name), defended_damage]
	_consume_main_action()

func _select_party_from_button(character_name: String) -> void:
	debug_click_movement("selection button: %s" % character_name)
	_execute_text_command("select " + character_name)
	_update_party_buttons()

func _update_party_buttons() -> void:
	if party_buttons == null:
		return
	for entry in [["AdventurerButton", "Player"], ["ScoutButton", "Scout"]]:
		var button := party_buttons.get_node_or_null(NodePath(str(entry[0]))) as Button
		var actor := get_node_or_null(NodePath(str(entry[1])))
		if button == null:
			continue
		button.visible = actor != null
		if actor == null:
			continue
		button.set_pressed_no_signal(bool(actor.get("is_selected")))
		button.tooltip_text = "%s — HP: %d | Weapon: %s" % [_actor_display_name(actor.name), _current_party_health(actor as Node3D), _party_weapon_name(actor.name)]
		button.disabled = combat_active and (combat_turn_order.is_empty() or _is_combat_enemy(combat_turn_order[current_turn_index]) or int(party_health.get(actor.name, 0)) <= 0 or (SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION and combat_turn_order[current_turn_index] != actor.name))

func _update_combat_display() -> void:
	_update_party_buttons()
	_update_turn_name_highlight()
	_update_weapon_selector()
	_update_feat_selector()
	_update_power_attack_selector()

	if attack_button != null:
		attack_button.visible = combat_active
		attack_button.disabled = combat_turn_order.is_empty() or not is_party_member_turn(combat_turn_order[current_turn_index]) or action_points <= 0 or not _standard_available(combat_turn_order[current_turn_index])
	if charge_button != null:
		charge_button.visible = combat_active
		charge_button.disabled = combat_turn_order.is_empty() or not is_party_member_turn(combat_turn_order[current_turn_index]) or action_points <= 0 or not _standard_available(combat_turn_order[current_turn_index]) or not bool(party_move_available.get(combat_turn_order[current_turn_index], false))
	if withdraw_button != null:
		withdraw_button.visible = combat_active
		withdraw_button.disabled = combat_turn_order.is_empty() or not can_begin_withdraw(combat_turn_order[current_turn_index])
	if full_attack_button != null:
		var full_attack_actor := "" if combat_turn_order.is_empty() else combat_turn_order[current_turn_index]
		full_attack_button.visible = combat_active and _full_attack_count(full_attack_actor) >= 2
		full_attack_button.disabled = not _can_full_attack(full_attack_actor)
	if defend_button != null:
		defend_button.visible = combat_active
		defend_button.disabled = combat_turn_order.is_empty() or not is_party_member_turn(combat_turn_order[current_turn_index]) or action_points <= 0 or not _standard_available(combat_turn_order[current_turn_index])
	if end_turn_button != null:
		end_turn_button.visible = combat_active
		end_turn_button.disabled = not combat_active
	if potion_button != null:
		potion_button.disabled = not _can_use_healing_potion()
	if five_foot_step_button != null:
		five_foot_step_button.visible = combat_active
		five_foot_step_button.disabled = combat_turn_order.is_empty() or not can_begin_five_foot_step(combat_turn_order[current_turn_index])

	if not combat_active:
		combat_live_status = ""
		_refresh_combat_log()
		return

	var lines := PackedStringArray(["Combat — Round %d" % combat_round, "Turn order:"])
	if not combat_turn_order.is_empty() and is_party_member_turn(combat_turn_order[current_turn_index]):
		if SWITCH_STANDARD_MOVE_ACTIONS:
			var actor_name := combat_turn_order[current_turn_index]
			lines.append("Standard: %s | Move: %s" % ["available" if _standard_available(actor_name) else "spent", "available" if bool(party_move_available.get(actor_name, false)) else "spent"])
		else:
			lines.append("Action points: %d / %d" % [action_points, ACTION_POINTS_PER_TURN])
	var quest_objective := _quest_objective_text()
	if not quest_objective.is_empty():
		lines.append(quest_objective)
	var inventory_status := _inventory_status_text()
	if not inventory_status.is_empty():
		lines.append(inventory_status)
	if not save_status_text.is_empty():
		lines.append(save_status_text)
	for index in range(combat_turn_order.size()):
		var turn_marker := "> " if index == current_turn_index else "  "
		var actor_name := combat_turn_order[index]
		var turn_line := "%s%s" % [turn_marker, _actor_display_name(actor_name)]
		if _is_combat_enemy(actor_name):
			turn_line += " — HP: %d" % int(combat_enemy_health.get(actor_name, 0))
		if index == current_turn_index:
			turn_line = "[color=#%s]%s[/color]" % [SWITCH_ACTIVE_ACTOR_TEXT_COLOR.to_html(false), turn_line]
		lines.append(turn_line)
	lines.append("Press Space or click End Turn")
	combat_live_status = "\n".join(lines)
	_refresh_combat_log()

func _power_attack_limit(actor_name: String) -> int:
	var data: Dictionary = party_character_data.get(actor_name, {})
	var base_attack := int(data.get("base_attack_bonus", 0))
	if not _has_feat_effect(actor_name, "melee_attack_tradeoff"):
		return 0
	return base_attack

func _lock_power_attack(actor_name: String) -> int:
	power_attack_locked[actor_name] = true
	return int(power_attack_penalties.get(actor_name, 0))

func _on_power_attack_selected(index: int) -> void:
	if not combat_active or combat_turn_order.is_empty():
		return
	var actor_name := combat_turn_order[current_turn_index]
	if not is_party_member_turn(actor_name) or bool(power_attack_locked.get(actor_name, false)):
		return
	power_attack_penalties[actor_name] = clampi(index, 0, _power_attack_limit(actor_name))
	_update_combat_display()

func _update_power_attack_selector() -> void:
	if power_attack_selector == null:
		return
	var actor_name := "" if combat_turn_order.is_empty() else combat_turn_order[current_turn_index]
	var limit := _power_attack_limit(actor_name) if combat_active and is_party_member_turn(actor_name) else 0
	power_attack_selector.visible = limit > 0
	if limit <= 0:
		return
	power_attack_selector.clear()
	var feat_name := _feat_name_for_effect(actor_name, "melee_attack_tradeoff")
	for penalty in range(limit + 1):
		power_attack_selector.add_item("%s: -%d / +%d" % [feat_name, penalty, penalty])
	power_attack_selector.select(clampi(int(power_attack_penalties.get(actor_name, 0)), 0, limit))
	power_attack_selector.disabled = bool(power_attack_locked.get(actor_name, false)) or action_points <= 0 or not _standard_available(actor_name)

func _update_feat_selector() -> void:
	if feat_selector == null:
		return
	feat_selector.clear()
	feat_selector.visible = false
	if combat_active:
		return
	var actor := _current_potion_user()
	if actor == null:
		return
	var choices := _eligible_feat_ids(actor.name)
	if choices.is_empty():
		return
	feat_selector.visible = true
	feat_selector.add_item("Choose feat")
	for feat_id in choices:
		var feat: Dictionary = feat_definitions[feat_id]
		feat_selector.add_item(str(feat["display_name"]))
		feat_selector.set_item_metadata(feat_selector.item_count - 1, feat_id)

func _on_feat_selected(index: int) -> void:
	if feat_selector == null or index <= 0 or index >= feat_selector.item_count:
		return
	var feat_id := str(feat_selector.get_item_metadata(index))
	var result := _execute_text_command("choose_feat " + feat_id)
	if not result.begins_with("{"):
		show_interaction_message(result)
	_update_feat_selector()

func _has_feat_effect(actor_name: String, effect: String) -> bool:
	var data: Dictionary = party_character_data.get(actor_name, {})
	for feat_id in data.get("feats", []):
		var feat: Dictionary = feat_definitions.get(feat_id, {})
		if str(feat.get("effect", "")) == effect:
			return true
	return false

func _feat_name_for_effect(actor_name: String, effect: String) -> String:
	var data: Dictionary = party_character_data.get(actor_name, {})
	for feat_id in data.get("feats", []):
		var feat: Dictionary = feat_definitions.get(feat_id, {})
		if str(feat.get("effect", "")) == effect:
			return str(feat.get("display_name", feat_id))
	return "Feat"

func _update_weapon_selector() -> void:
	if weapon_selector == null:
		return
	weapon_selector.visible = not combat_active
	weapon_selector.clear()
	if combat_active:
		return
	var actor := _current_potion_user()
	weapon_selector.disabled = actor == null
	if actor == null:
		return
	var current_weapon: Dictionary = party_weapon_data.get(actor.name, {})
	for weapon_id in ["training_sword", "iron_sword"]:
		if weapon_id == "iron_sword" and int(inventory.get("iron_sword", 0)) < 1:
			continue
		var weapon := _load_weapon_data(weapon_id)
		if weapon.is_empty():
			continue
		weapon_selector.add_item(str(weapon["display_name"]))
		var index := weapon_selector.item_count - 1
		weapon_selector.set_item_metadata(index, weapon_id)
		if weapon_id == "iron_sword":
			for member_name in equipped_weapons:
				if member_name != actor.name and equipped_weapons[member_name] == weapon_id:
					weapon_selector.set_item_disabled(index, true)
		if current_weapon.get("id", "") == weapon_id:
			weapon_selector.select(index)

func _on_weapon_selected(index: int) -> void:
	if weapon_selector == null or index < 0 or index >= weapon_selector.item_count:
		return
	var weapon_id := str(weapon_selector.get_item_metadata(index))
	var result := _execute_text_command("equip " + weapon_id)
	if not result.begins_with("{"):
		show_interaction_message(result)
		_update_weapon_selector()

func _update_turn_name_highlight() -> void:
	var active_actor_name := ""
	if combat_active and not combat_turn_order.is_empty():
		active_actor_name = combat_turn_order[current_turn_index]

	for party_member in get_tree().get_nodes_in_group("party_members"):
		_set_actor_name_highlight(party_member, party_member.name == active_actor_name)

	for enemy in _living_combat_enemies():
		_set_actor_name_highlight(enemy, enemy.name == active_actor_name)

func _set_actor_name_highlight(actor: Node3D, active: bool) -> void:
	var name_label := actor.get_node_or_null("NameLabel") as Label3D
	if name_label == null:
		return

	var actor_id := actor.get_instance_id()
	if not actor_base_name_colors.has(actor_id):
		actor_base_name_colors[actor_id] = name_label.modulate
	if active:
		name_label.modulate = Color(1.0, 0.12, 0.12, 1.0)
	else:
		name_label.modulate = actor_base_name_colors[actor_id]

func is_combat_active() -> bool:
	return combat_active

func _on_command_menu_selected(id: int) -> void:
	if command_menu == null or command_input == null:
		return
	var popup := command_menu.get_popup()
	var index := popup.get_item_index(id)
	if index < 0:
		return
	command_input.text = popup.get_item_text(index) + " "
	command_input.grab_focus()
	command_input.caret_column = command_input.text.length()

func _submit_text_command(command: String) -> void:
	var result := _execute_text_command(command, "  ")
	_append_shared_text(result)
	if command_input != null:
		command_input.clear()

func _execute_text_command(command: String, indent: String = "") -> String:
	var normalized_command := command.strip_edges().to_lower()
	if normalized_command == "inspect":
		return JSON.stringify(inspect_game_state(), indent)
	if normalized_command.begins_with("equip "):
		if combat_active:
			return "Cannot change weapons during combat."
		var actor := _current_potion_user()
		if actor == null:
			return "No party member selected."
		var weapon_id := normalized_command.trim_prefix("equip ").strip_edges()
		if weapon_id != "training_sword" and (weapon_id != "iron_sword" or int(inventory.get("iron_sword", 0)) < 1):
			return "Weapon is not available."
		if weapon_id == "iron_sword":
			for member_name in equipped_weapons:
				if member_name != actor.name and equipped_weapons[member_name] == weapon_id:
					return "Iron Sword is already equipped by another party member."
		var weapon := _load_weapon_data(weapon_id)
		if weapon.is_empty():
			return "Weapon data is invalid."
		equipped_weapons[actor.name] = weapon_id
		party_weapon_data[actor.name] = weapon
		_persist_equipped_weapons()
		_update_combat_display()
		return JSON.stringify(inspect_game_state(), indent)
	if normalized_command == "save":
		_save_game()
		return save_status_text
	if normalized_command == "load":
		_load_game()
		if get_tree().has_meta("pending_save_restore"):
			return "Load requested."
		return save_status_text
	if normalized_command == "dialogue_choice":
		if dialogue_panel == null or not dialogue_panel.visible or dialogue_choice_button == null or not dialogue_choice_button.visible or dialogue_choice_button.disabled:
			return "No dialogue choice is available."
		_accept_trail_quest()
		if dialogue_panel.visible and dialogue_text != null:
			return dialogue_text.text
		return "Dialogue closed."
	if normalized_command == "dialogue_influence":
		if dialogue_panel == null or not dialogue_panel.visible or dialogue_influence_button == null or not dialogue_influence_button.visible or dialogue_influence_button.disabled:
			return "No Influence dialogue choice is available."
		_use_trail_warden_influence()
		return dialogue_text.text if dialogue_text != null else "Influence dialogue choice used."
	if normalized_command == "dialogue_lore":
		if dialogue_panel == null or not dialogue_panel.visible or dialogue_lore_button == null or not dialogue_lore_button.visible or dialogue_lore_button.disabled:
			return "No Lore dialogue choice is available."
		_use_trail_warden_lore()
		return dialogue_text.text if dialogue_text != null else "Lore dialogue choice used."
	if normalized_command == "dialogue_decline":
		if dialogue_panel == null or not dialogue_panel.visible or dialogue_decline_button == null or not dialogue_decline_button.visible or dialogue_decline_button.disabled:
			return "No decline choice is available."
		_decline_trail_quest()
		return "Dialogue closed."
	var args := normalized_command.split(" ", false)
	if args.is_empty():
		return "Unknown command."
	if args[0] == "choose_feat":
		if args.size() != 2:
			return "Use choose_feat <feat_id>."
		if combat_active:
			return "Feats can be selected during exploration only."
		var feat_actor := _current_potion_user()
		if feat_actor == null:
			return "No party member selected."
		return _choose_feat(feat_actor.name, args[1], indent)
	if args[0] == "select":
		if args.size() != 2 or (combat_active and (SWITCH_FORCE_PLAYERS_ORDER_OF_ACTION or combat_turn_order.is_empty() or _is_combat_enemy(combat_turn_order[current_turn_index]))):
			return "Cannot select a party member now: select <character>."
		for member in get_tree().get_nodes_in_group("party_members"):
			if str(member.name).to_lower() == args[1] or _actor_display_name(member.name).to_lower() == args[1]:
				if combat_active:
					if int(party_health.get(member.name, 0)) <= 0:
						return "Party member is down."
					current_turn_index = combat_turn_order.find(member.name)
					action_points = _party_points(member.name)
				for other in get_tree().get_nodes_in_group("party_members"):
					other.call("set_selected", other == member)
				get_tree().set_meta("selected_party_member", member.name)
				_update_combat_display()
				return JSON.stringify(inspect_game_state(), indent)
		return "Party member not found."
	if args[0] == "move":
		if args.size() != 3 or not args[1].is_valid_float() or not args[2].is_valid_float():
			return "Use move <x> <z>."
		var x := float(args[1])
		var z := float(args[2])
		if not is_finite(x) or not is_finite(z) or absf(x) > 10.0 or absf(z) > 10.0:
			return "Movement target is outside the area."
		var actor := _current_potion_user()
		if actor == null or (combat_active and not can_party_move(actor.name)):
			return "No party member can move."
		actor.call("set_movement_destination", Vector3(x, 0.0, z))
		return "Movement started."
	if args[0] == "move_enemy":
		if args.size() != 4 or not args[2].is_valid_float() or not args[3].is_valid_float():
			return "Use move_enemy <enemy> <x> <z>."
		if not combat_active:
			return "Enemy test movement is available during combat only."
		var x := float(args[2])
		var z := float(args[3])
		if not is_finite(x) or not is_finite(z) or absf(x) > 10.0 or absf(z) > 10.0:
			return "Movement target is outside the area."
		for enemy in _living_combat_enemies():
			if enemy.name.to_lower() == args[1]:
				if bool(enemy.call("move_to_test_destination", Vector3(x, 0.0, z))):
					return "Enemy test movement started."
				return "Enemy cannot find a clear grid route."
		return "Enemy not found."
	if args[0] == "five_foot_step":
		if args.size() != 3 or not args[1].is_valid_float() or not args[2].is_valid_float():
			return "Use five_foot_step <x> <z>."
		var x := float(args[1])
		var z := float(args[2])
		if not is_finite(x) or not is_finite(z) or absf(x) > 10.0 or absf(z) > 10.0:
			return "Movement target is outside the area."
		var actor := _current_potion_user()
		if actor == null or not can_begin_five_foot_step(actor.name):
			return "A 5-foot step is not available."
		actor.call("begin_five_foot_step")
		actor.call("set_movement_destination", Vector3(x, 0.0, z))
		return "5-foot step started."
	if args[0] == "withdraw":
		if args.size() != 3 or not args[1].is_valid_float() or not args[2].is_valid_float():
			return "Use withdraw <x> <z>."
		var withdraw_actor := _current_potion_user()
		if withdraw_actor == null or not can_begin_withdraw(withdraw_actor.name):
			return "Withdraw is not available."
		withdraw_actor.call("begin_withdraw")
		withdraw_actor.call("set_movement_destination", Vector3(float(args[1]), 0.0, float(args[2])))
		return "Withdraw started."
	if args[0] == "interact":
		if args.size() != 2 or combat_active:
			return "Use interact <target> during exploration."
		var actor := _current_potion_user()
		if actor == null:
			return "No party member selected."
		for child in get_children():
			if child is Node3D and not child.is_queued_for_deletion() and str(child.name).to_lower() == args[1]:
				return str(actor.call("interact_by_command", child))
		return "Target not found."
	if args[0] == "attack":
		if args.size() != 2 or not combat_active or combat_turn_order.is_empty() or not is_party_member_turn(combat_turn_order[current_turn_index]) or action_points <= 0 or not _standard_available(combat_turn_order[current_turn_index]):
			return "Cannot attack: no party member has a main action available."
		var enemy: CollisionObject3D
		for candidate in _living_combat_enemies():
			if candidate.name.to_lower() == args[1]:
				enemy = candidate
				break
		if enemy == null:
			return "Cannot attack: enemy not found."
		_attack_enemy(enemy)
		return JSON.stringify({"message": combat_log_text, "state": inspect_game_state()}, indent)
	if args[0] == "charge":
		if args.size() != 2 or not combat_active or combat_turn_order.is_empty() or not is_party_member_turn(combat_turn_order[current_turn_index]):
			return "Cannot charge now."
		var enemy: CollisionObject3D
		for candidate in _living_combat_enemies():
			if candidate.name.to_lower() == args[1]:
				enemy = candidate
				break
		if enemy == null:
			return "Cannot charge: enemy not found."
		combat_enemy_name = enemy.name
		_charge_current_enemy()
		return JSON.stringify({"message": combat_log_text, "state": inspect_game_state()}, indent)
	if args[0] == "full_attack":
		if args.size() != 2 or not combat_active or combat_turn_order.is_empty() or not is_party_member_turn(combat_turn_order[current_turn_index]) or not _can_full_attack(combat_turn_order[current_turn_index]):
			return "Cannot make a full attack now."
		var enemy: CollisionObject3D
		for candidate in _living_combat_enemies():
			if candidate.name.to_lower() == args[1]:
				enemy = candidate
				break
		if enemy == null:
			return "Cannot make a full attack: enemy not found."
		combat_enemy_name = enemy.name
		_full_attack_current_enemy()
		return JSON.stringify({"message": combat_log_text, "state": inspect_game_state()}, indent)
	if normalized_command == "defend":
		if not combat_active or combat_turn_order.is_empty() or not is_party_member_turn(combat_turn_order[current_turn_index]) or action_points <= 0 or not _standard_available(combat_turn_order[current_turn_index]):
			return "Cannot defend: no party member has a main action available."
		_defend_current_actor()
		return JSON.stringify({"message": combat_log_text, "state": inspect_game_state()}, indent)
	if normalized_command == "use_potion":
		if not _can_use_healing_potion():
			return "Cannot use a healing potion."
		_use_healing_potion()
		return JSON.stringify(inspect_game_state(), indent)
	if normalized_command.begins_with("start_combat "):
		if combat_active:
			return "Cannot start combat: combat is already active."
		var enemy_name := normalized_command.trim_prefix("start_combat ").strip_edges()
		for child in get_children():
			if child is Node3D and child.has_meta("combat_enemy") and not child.is_queued_for_deletion() and str(child.name).to_lower() == enemy_name:
				_start_combat(str(child.name))
				return JSON.stringify(inspect_game_state(), indent)
		return "Cannot start combat: enemy not found."
	if normalized_command == "end_turn":
		if not combat_active or combat_turn_order.is_empty() or not is_party_member_turn(combat_turn_order[current_turn_index]):
			return "Cannot end turn: no party member is taking a turn."
		_resolve_current_turn()
		return JSON.stringify(inspect_game_state(), indent)
	return "Unknown command."

func _process(delta: float) -> void:
	_update_target_visuals()
	if command_client == null and command_server.is_connection_available():
		command_client = command_server.take_connection()
		command_buffer.clear()
		command_client_elapsed = 0.0
	if command_client == null:
		return
	command_client_elapsed += delta
	if command_client_elapsed > 5.0:
		command_client.disconnect_from_host()
		command_client = null
		command_buffer.clear()
		return
	command_client.poll()
	if command_client.get_status() != StreamPeerTCP.STATUS_CONNECTED:
		command_client = null
		command_buffer.clear()
		return
	var available := command_client.get_available_bytes()
	if available <= 0:
		return
	if command_buffer.size() + available > MAX_COMMAND_BYTES:
		command_client.disconnect_from_host()
		command_client = null
		command_buffer.clear()
		return
	var received := command_client.get_data(available)
	if received[0] != OK:
		command_client.disconnect_from_host()
		command_client = null
		command_buffer.clear()
		return
	command_buffer.append_array(received[1])
	var newline := command_buffer.find(10)
	if newline >= 0:
		var command := command_buffer.slice(0, newline).get_string_from_utf8()
		command_client.put_data((_execute_text_command(command) + "\n").to_utf8_buffer())
		command_client.disconnect_from_host()
		command_client = null
		command_buffer.clear()

func _setup_target_visuals() -> void:
	var shader := Shader.new()
	shader.code = "shader_type spatial; uniform vec4 target_color : source_color; uniform bool highlighted = false; uniform bool lower_colored = true; varying float local_height; void vertex() { local_height = VERTEX.y; } void fragment() { ALBEDO = (highlighted || (lower_colored && local_height < 0.0)) ? target_color.rgb : vec3(0.75); }"
	for child in get_children():
		if not child is Node3D or (not child.has_meta("combat_enemy") and not child.has_meta("interaction_dialogue") and not child.is_in_group("party_members")):
			continue
		var body := child.get_node_or_null("MeshInstance3D") as MeshInstance3D
		if body == null:
			continue
		var material := ShaderMaterial.new()
		material.shader = shader
		material.set_shader_parameter("target_color", Color(0.12, 0.75, 0.2) if child.has_meta("interaction_dialogue") else Color(0.85, 0.12, 0.12))
		material.set_shader_parameter("lower_colored", not child.is_in_group("party_members"))
		body.material_override = material
		target_materials[child.get_instance_id()] = material
	targeting_line = MeshInstance3D.new()
	var line_material := StandardMaterial3D.new()
	line_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	line_material.vertex_color_use_as_albedo = true
	targeting_line.material_override = line_material
	targeting_line.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(targeting_line)

func _update_target_visuals() -> void:
	var hovered: Node3D
	if get_viewport().gui_get_hovered_control() == null:
		var hit := _get_mouse_hit(get_viewport().get_mouse_position())
		if not hit.is_empty() and hit["collider"] is Node3D:
			hovered = hit["collider"] as Node3D
	for child in get_children():
		if target_materials.has(child.get_instance_id()):
			var material: ShaderMaterial = target_materials[child.get_instance_id()]
			var can_highlight := (combat_active and ctrl_down) if child.is_in_group("party_members") else (not child.has_meta("combat_enemy") or combat_active)
			material.set_shader_parameter("highlighted", child == hovered and can_highlight)
	if targeting_line == null:
		return
	targeting_line.visible = false
	if not combat_active or combat_turn_order.is_empty() or not is_party_member_turn(combat_turn_order[current_turn_index]) or get_viewport().gui_get_hovered_control() != null:
		return
	var actor := _current_potion_user()
	if actor == null or _actor_is_moving(actor):
		return
	var party_target := hovered != null and hovered.is_in_group("party_members")
	if party_target and not ctrl_down:
		return
	if party_target:
		if hovered == actor:
			return
		var party_mesh := ImmediateMesh.new()
		party_mesh.surface_begin(Mesh.PRIMITIVE_LINES)
		var can_attack := action_points > 0 and _current_party_health(hovered) > 0 and actor.global_position.distance_to(hovered.global_position) <= MELEE_ATTACK_RANGE and _has_clear_attack_path(actor as CollisionObject3D, hovered as CollisionObject3D)
		party_mesh.surface_set_color(Color.GREEN if can_attack else Color.RED)
		party_mesh.surface_add_vertex(actor.global_position + Vector3.UP * 0.08)
		party_mesh.surface_add_vertex(hovered.global_position + Vector3.UP * 0.08)
		party_mesh.surface_end()
		targeting_line.mesh = party_mesh
		targeting_line.visible = true
		return

	var camera := get_viewport().get_camera_3d()
	if camera == null:
		return
	var origin := camera.project_ray_origin(get_viewport().get_mouse_position())
	var direction := camera.project_ray_normal(get_viewport().get_mouse_position())
	if direction.y >= -0.0001:
		return
	var ground := origin + direction * (-origin.y / direction.y)
	if absf(ground.x) > 10.0 or absf(ground.z) > 10.0:
		return
	var enemy_target := hovered != null and hovered.has_meta("combat_enemy") and _is_combat_enemy(hovered.name)
	var navigation_agent := actor.get("navigation_agent") as NavigationAgent3D
	if navigation_agent == null:
		return
	var map := navigation_agent.get_navigation_map()
	if NavigationServer3D.map_get_iteration_id(map) == 0:
		return
	var path: PackedVector3Array
	var grid_step_costs := PackedInt32Array()
	var attack_from_here := enemy_target and actor.global_position.distance_to(hovered.global_position) <= MELEE_ATTACK_RANGE and _has_clear_attack_path(actor as CollisionObject3D, hovered as CollisionObject3D)
	if attack_from_here:
		path = PackedVector3Array([actor.global_position, hovered.global_position])
	elif enemy_target:
		var route: Dictionary = get_combat_grid_approach_route(actor as CollisionObject3D, hovered as CollisionObject3D) if uses_tactical_grid() else actor.call("get_enemy_approach_route", hovered)
		path = route.get("path", PackedVector3Array())
		grid_step_costs = route.get("step_costs", PackedInt32Array())
	else:
		if uses_tactical_grid():
			var route := get_combat_grid_route(actor as CollisionObject3D, ground)
			path = route.get("path", PackedVector3Array())
			grid_step_costs = route.get("step_costs", PackedInt32Array())
		else:
			path = NavigationServer3D.map_get_path(map, actor.global_position, ground, true)
	if path.size() < 2:
		return
	var movement_limit := get_combat_movement_limit(actor.name)
	var green_limit := float(action_points * movement_limit)
	if enemy_target and not attack_from_here:
		green_limit = float(maxi(action_points - 1, 0) * movement_limit)
	var yellow_limit := float(action_points * movement_limit)
	if SWITCH_STANDARD_MOVE_ACTIONS and enemy_target and not _standard_available(actor.name):
		green_limit = 0.0
		yellow_limit = 0.0
	var mesh := ImmediateMesh.new()
	mesh.surface_begin(Mesh.PRIMITIVE_LINES)
	if uses_tactical_grid() and grid_step_costs.size() == path.size() - 1:
		var grid_cost := 0
		var green_grid_limit := movement_limit if enemy_target and _standard_available(actor.name) and bool(party_move_available.get(actor.name, false)) else action_points * movement_limit
		var yellow_grid_limit := action_points * movement_limit
		for i in range(1, path.size()):
			grid_cost += grid_step_costs[i - 1]
			var color := Color.GREEN if grid_cost <= green_grid_limit else Color.YELLOW if enemy_target and grid_cost <= yellow_grid_limit else Color.RED
			mesh.surface_set_color(color)
			mesh.surface_add_vertex(path[i - 1] + Vector3.UP * 0.08)
			mesh.surface_add_vertex(path[i] + Vector3.UP * 0.08)
		mesh.surface_end()
		targeting_line.mesh = mesh
		targeting_line.visible = true
		return
	var distance := 0.0
	for i in range(1, path.size()):
		var start := path[i - 1]
		var end := path[i]
		var segment_length := start.distance_to(end)
		if segment_length <= 0.0001:
			continue
		var cursor := 0.0
		while cursor < segment_length - 0.0001:
			var travelled := distance + cursor
			var boundary := green_limit if travelled < green_limit - 0.0001 else yellow_limit if enemy_target and travelled < yellow_limit - 0.0001 else INF
			var next := minf(segment_length, cursor + boundary - travelled)
			var color := Color.GREEN if travelled < green_limit - 0.0001 else Color.YELLOW if enemy_target and travelled < yellow_limit - 0.0001 else Color.RED
			mesh.surface_set_color(color)
			mesh.surface_add_vertex(start.lerp(end, cursor / segment_length) + Vector3.UP * 0.08)
			mesh.surface_add_vertex(start.lerp(end, next / segment_length) + Vector3.UP * 0.08)
			cursor = next
		distance += segment_length
	if not enemy_target and path[-1].distance_to(ground) > 0.3:
		mesh.surface_set_color(Color.RED)
		mesh.surface_add_vertex(path[-1] + Vector3.UP * 0.08)
		mesh.surface_add_vertex(ground + Vector3.UP * 0.08)
	mesh.surface_end()
	targeting_line.mesh = mesh
	targeting_line.visible = true

func inspect_game_state() -> Dictionary:
	var party: Array[Dictionary] = []
	var selected_member: Node3D
	for member in get_tree().get_nodes_in_group("party_members"):
		party.append({"name": _actor_display_name(member.name), "health": _current_party_health(member), "speed_feet": int(party_character_data.get(member.name, {}).get("speed_feet", DEFAULT_COMBAT_SPEED_FEET)), "skills": party_skill_totals.get(member.name, {}), "equipped_weapon": _party_weapon_name(member.name), "position": {"x": member.global_position.x, "z": member.global_position.z}, "selected": bool(member.get("is_selected")), "moving": bool(member.get("has_destination")) or bool(member.get("has_pending_destination")), "action_points": _party_points(member.name) if combat_active else 0})
		if bool(member.get("is_selected")):
			selected_member = member as Node3D
	var enemies: Array[Dictionary] = []
	var interactables: Array[Dictionary] = []
	for child in get_children():
		if child is Node3D and child.has_meta("combat_enemy") and not child.is_queued_for_deletion():
			enemies.append({"name": str(child.name), "health": int(child.get_meta("health", 10))})
		if selected_member != null and child is Node3D and not child.is_queued_for_deletion() and (child.has_meta("interaction_scene") or child.has_meta("interaction_text") or child.has_meta("interaction_dialogue") or child.has_meta("interaction_item")) and selected_member.global_position.distance_to(child.global_position) <= get_interaction_distance(selected_member.name):
			interactables.append({"name": str(child.name), "position": {"x": child.global_position.x, "z": child.global_position.z}})
	var active_turn := ""
	if combat_active and not combat_turn_order.is_empty():
		active_turn = _actor_display_name(combat_turn_order[current_turn_index])
	var recent_log_start := maxi(0, combat_log_history.size() - INSPECT_RECENT_LOG_LIMIT)
	var recent_log_messages := combat_log_history.slice(recent_log_start)
	return {
		"area": scene_file_path,
		"party": party,
		"enemies": enemies,
		"nearby_interactables": interactables,
		"quest_objective": _quest_objective_text(),
		"combat_active": combat_active,
		"combat_message": combat_log_text,
		"recent_log_messages": recent_log_messages,
		"active_turn": active_turn,
		"movement_debug_log": movement_debug_log
	}

func _selected_party_member_name() -> String:
	for member in get_tree().get_nodes_in_group("party_members"):
		if bool(member.get("is_selected")):
			return member.name
	return ""

func get_party_skill_total(member_name: String, skill_id: String) -> int:
	return int((party_skill_totals.get(member_name, {}) as Dictionary).get(skill_id, 0))

func get_interaction_distance(member_name: String) -> float:
	return 2.5 + 0.5 * float(maxi(0, get_party_skill_total(member_name, "awareness")))

func _load_feat_data() -> Dictionary:
	var file := FileAccess.open(FEAT_DATA_PATH, FileAccess.READ)
	if file == null:
		push_error("Could not open feat data: %s" % FEAT_DATA_PATH)
		return {}
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if not parsed is Dictionary or not parsed.get("feats", null) is Dictionary or parsed["feats"].is_empty():
		push_error("Feat data must contain a non-empty feats object: %s" % FEAT_DATA_PATH)
		return {}
	for feat_id in parsed["feats"]:
		var feat: Variant = parsed["feats"][feat_id]
		if not feat_id is String or not feat_id.is_valid_identifier() or not feat is Dictionary or feat.get("id") != feat_id or not feat.get("display_name") is String or str(feat["display_name"]).is_empty() or not feat.get("description") is String or not feat.get("requirements", {}) is Dictionary or not feat.get("effect") is String:
			push_error("Feat data has an invalid feat definition: %s" % FEAT_DATA_PATH)
			return {}
	return parsed["feats"]

func _apply_saved_feat_selection(actor_name: String, character_data: Dictionary) -> Dictionary:
	var result := character_data.duplicate(true)
	var feats: Variant = result.get("feats", [])
	if not feats is Array:
		push_error("Character feats must be an array: %s" % result.get("id", actor_name))
		return {}
	for feat_id in feats:
		if not feat_id is String or not feat_definitions.has(feat_id):
			push_error("Character has an unknown feat: %s" % result.get("id", actor_name))
			return {}
	var selected: Variant = party_selected_feats.get(actor_name, [])
	if not selected is Array:
		push_error("Saved feat choices are invalid for %s." % actor_name)
		return {}
	for feat_id in selected:
		if not feat_id is String or feats.has(feat_id) or not feat_definitions.has(feat_id) or not _feat_meets_requirements(result, feat_id):
			push_error("Saved feat choice is invalid for %s." % actor_name)
			return {}
		feats.append(feat_id)
	result["feats"] = feats
	if feats.size() > _available_feat_slots(result):
		push_error("Character has more feats than available slots: %s" % result.get("id", actor_name))
		return {}
	return result

func _available_feat_slots(character_data: Dictionary) -> int:
	var level := int(character_data.get("level", 1))
	return 1 + floori(float(level) / 3.0) + int(character_data.get("ancestry_bonus_feat_slots", 0)) + int(character_data.get("class_bonus_feat_slots", 0))

func _feat_meets_requirements(character_data: Dictionary, feat_id: String) -> bool:
	var feat: Dictionary = feat_definitions.get(feat_id, {})
	var requirements: Dictionary = feat.get("requirements", {})
	if int(character_data.get("base_attack_bonus", 0)) < int(requirements.get("base_attack_bonus", 0)):
		return false
	var attributes: Dictionary = character_data.get("attributes", {})
	var required_attributes: Variant = requirements.get("attributes", {})
	if not required_attributes is Dictionary:
		return false
	for attribute_name in required_attributes:
		if int(attributes.get(attribute_name, 0)) < int(required_attributes[attribute_name]):
			return false
	return true

func _eligible_feat_ids(actor_name: String) -> Array[String]:
	var data: Dictionary = party_character_data.get(actor_name, {})
	var choices: Array[String] = []
	var feats: Array = data.get("feats", [])
	if feats.size() >= _available_feat_slots(data):
		return choices
	for feat_id in feat_definitions:
		if not feats.has(feat_id) and _feat_meets_requirements(data, feat_id):
			choices.append(feat_id)
	choices.sort()
	return choices

func _choose_feat(actor_name: String, feat_id: String, indent: String) -> String:
	if not _eligible_feat_ids(actor_name).has(feat_id):
		return "That feat is not available."
	var data: Dictionary = party_character_data[actor_name]
	var feats: Array = data.get("feats", [])
	feats.append(feat_id)
	data["feats"] = feats
	party_character_data[actor_name] = data
	var selected: Array = party_selected_feats.get(actor_name, [])
	selected.append(feat_id)
	party_selected_feats[actor_name] = selected
	_persist_party_selected_feats()
	var feat: Dictionary = feat_definitions[feat_id]
	_append_shared_text("%s selects %s." % [_actor_display_name(actor_name), feat["display_name"]])
	_update_combat_display()
	return JSON.stringify(inspect_game_state(), indent)

func _load_skill_data() -> Dictionary:
	var file := FileAccess.open(SKILL_DATA_PATH, FileAccess.READ)
	if file == null:
		push_error("Could not open skill data: %s" % SKILL_DATA_PATH)
		return {}
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if not parsed is Dictionary or not parsed.get("skills", null) is Dictionary or parsed["skills"].is_empty():
		push_error("Skill data must contain a non-empty skills object: %s" % SKILL_DATA_PATH)
		return {}
	for skill_id in parsed["skills"]:
		var skill: Variant = parsed["skills"][skill_id]
		if not skill_id is String or not skill_id.is_valid_identifier() or not skill is Dictionary or not skill.get("ability", null) is String or not str(skill["ability"]).is_valid_identifier():
			push_error("Skill data has an invalid skill definition: %s" % SKILL_DATA_PATH)
			return {}
	return parsed["skills"]

func _load_character_skill_totals(character_data: Dictionary, skill_data: Dictionary) -> Dictionary:
	var ranks: Variant = character_data.get("skill_ranks", null)
	if not ranks is Dictionary:
		push_error("Character data is missing skill ranks: %s" % character_data.get("id", "unknown"))
		return {}
	for skill_id in ranks:
		var rank: Variant = ranks[skill_id]
		if not skill_id is String or not skill_data.has(skill_id) or typeof(rank) not in [TYPE_INT, TYPE_FLOAT] or floor(rank) != rank or rank < 0:
			push_error("Character data has invalid skill ranks: %s" % character_data.get("id", "unknown"))
			return {}
	var attributes: Dictionary = character_data["attributes"]
	var totals: Dictionary = {}
	for skill_id in skill_data:
		var ability := str(skill_data[skill_id]["ability"])
		var ability_score := int(attributes.get(ability, 10))
		totals[skill_id] = int(ranks.get(skill_id, 0)) + floori((float(ability_score) - 10.0) / 2.0)
	return totals

func _load_character_data(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		push_error("Character data file does not exist: %s" % path)
		return {}

	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		push_error("Could not open character data file: %s" % path)
		return {}

	var parsed_data: Variant = JSON.parse_string(file.get_as_text())
	if not parsed_data is Dictionary:
		push_error("Character data must contain a JSON object: %s" % path)
		return {}

	for required_field in ["id", "race", "display_name", "description", "attributes", "equipped_weapon", "attack_modifier", "defense", "speed_feet"]:
		if not parsed_data.has(required_field):
			push_error("Character data is missing required field '%s': %s" % [required_field, path])
			return {}

	if not parsed_data["id"] is String or parsed_data["id"].is_empty():
		push_error("Character data field 'id' must be a non-empty string: %s" % path)
		return {}
	if not parsed_data["race"] is String or not parsed_data["race"].is_valid_identifier():
		push_error("Character data field 'race' must be a valid race ID: %s" % path)
		return {}
	if not parsed_data["display_name"] is String or parsed_data["display_name"].is_empty():
		push_error("Character data field 'display_name' must be a non-empty string: %s" % path)
		return {}
	if not parsed_data["description"] is String:
		push_error("Character data field 'description' must be a string: %s" % path)
		return {}
	if not parsed_data["attributes"] is Dictionary:
		push_error("Character data field 'attributes' must be an object: %s" % path)
		return {}
	if not parsed_data["equipped_weapon"] is String or not parsed_data["equipped_weapon"].is_valid_identifier():
		push_error("Character data field 'equipped_weapon' must be a valid weapon ID: %s" % path)
		return {}
	for field in ["attack_modifier", "defense", "speed_feet"]:
		var value: Variant = parsed_data[field]
		if typeof(value) not in [TYPE_INT, TYPE_FLOAT] or floor(value) != value or (field == "speed_feet" and value < FEET_PER_GRID_CELL):
			push_error("Character data field '%s' must be an integer%s: %s" % [field, " of at least %d" % FEET_PER_GRID_CELL if field == "speed_feet" else "", path])
			return {}
	for attribute_name in parsed_data["attributes"]:
		var attribute_value: Variant = parsed_data["attributes"][attribute_name]
		if attribute_name.is_empty() or typeof(attribute_value) not in [TYPE_INT, TYPE_FLOAT]:
			push_error("Character data attributes must use non-empty names and numeric values: %s" % path)
			return {}

	return parsed_data

func _apply_race_effects(character_data: Dictionary) -> Dictionary:
	var file := FileAccess.open(RACE_DATA_PATH, FileAccess.READ)
	if file == null:
		push_error("Could not open race data: %s" % RACE_DATA_PATH)
		return {}
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if not parsed is Dictionary or not parsed.get("races", null) is Dictionary:
		push_error("Race data must contain a races object: %s" % RACE_DATA_PATH)
		return {}
	var race_id := str(character_data["race"])
	var race: Variant = parsed["races"].get(race_id, null)
	if not race is Dictionary or race.get("id") != race_id or not race.get("attribute_modifiers", null) is Dictionary:
		push_error("Character references an invalid race '%s'." % race_id)
		return {}
	var result := character_data.duplicate(true)
	var attributes: Dictionary = result["attributes"]
	for attribute_name in race["attribute_modifiers"]:
		var modifier: Variant = race["attribute_modifiers"][attribute_name]
		if typeof(modifier) not in [TYPE_INT, TYPE_FLOAT] or floor(modifier) != modifier:
			push_error("Race '%s' has an invalid attribute modifier." % race_id)
			return {}
		attributes[attribute_name] = int(attributes.get(attribute_name, 10)) + int(modifier)
	var speed_modifier: Variant = race.get("speed_feet_modifier", 0)
	if typeof(speed_modifier) not in [TYPE_INT, TYPE_FLOAT] or floor(speed_modifier) != speed_modifier:
		push_error("Race '%s' has an invalid speed modifier." % race_id)
		return {}
	result["speed_feet"] = maxi(FEET_PER_GRID_CELL, int(result["speed_feet"]) + int(speed_modifier))
	var bonus_slots: Variant = race.get("bonus_feat_slots", 0)
	if typeof(bonus_slots) not in [TYPE_INT, TYPE_FLOAT] or floor(bonus_slots) != bonus_slots or bonus_slots < 0:
		push_error("Race '%s' has an invalid bonus feat slot count." % race_id)
		return {}
	result["ancestry_bonus_feat_slots"] = int(bonus_slots)
	return result

func _apply_class_effects(character_data: Dictionary) -> Dictionary:
	var file := FileAccess.open(CLASS_DATA_PATH, FileAccess.READ)
	if file == null:
		push_error("Could not open class data: %s" % CLASS_DATA_PATH)
		return {}
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if not parsed is Dictionary or not parsed.get("classes", null) is Dictionary:
		push_error("Class data must contain a classes object: %s" % CLASS_DATA_PATH)
		return {}
	var class_id := str(character_data.get("class", ""))
	var class_data: Variant = parsed["classes"].get(class_id, null)
	if not class_data is Dictionary or class_data.get("id") != class_id or not class_data.get("progression", null) is Array:
		push_error("Character references an invalid class '%s'." % class_id)
		return {}
	var experience := int(character_data.get("experience", 0))
	var entry: Dictionary = {}
	for candidate in class_data["progression"]:
		if candidate is Dictionary and int(candidate.get("experience_required", -1)) <= experience and (entry.is_empty() or int(candidate.get("level", 0)) > int(entry.get("level", 0))):
			entry = candidate
	if entry.is_empty():
		push_error("Class '%s' has no progression entry for %d XP." % [class_id, experience])
		return {}
	for field in ["level", "base_health", "base_attack_bonus"]:
		if typeof(entry.get(field)) not in [TYPE_INT, TYPE_FLOAT] or int(entry[field]) < 1:
			push_error("Class '%s' has an invalid %s progression value." % [class_id, field])
			return {}
	var result := character_data.duplicate(true)
	result["level"] = int(entry["level"])
	result["base_health"] = int(entry["base_health"])
	result["base_attack_bonus"] = int(entry["base_attack_bonus"])
	var bonus_slots: Variant = entry.get("bonus_feat_slots", 0)
	if typeof(bonus_slots) not in [TYPE_INT, TYPE_FLOAT] or floor(bonus_slots) != bonus_slots or bonus_slots < 0:
		push_error("Class '%s' has an invalid bonus feat slot count." % class_id)
		return {}
	result["class_bonus_feat_slots"] = int(bonus_slots)
	return result

func _load_weapon_data(weapon_id: String) -> Dictionary:
	if not weapon_id.is_valid_identifier():
		push_error("Weapon ID is invalid: %s" % weapon_id)
		return {}
	var path := "res://data/weapons/%s.json" % weapon_id
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		push_error("Could not open weapon data file: %s" % path)
		return {}
	var data: Variant = JSON.parse_string(file.get_as_text())
	if not data is Dictionary or data.get("id") != weapon_id or not data.get("display_name") is String or data["display_name"].is_empty():
		push_error("Weapon data has an invalid ID or display name: %s" % path)
		return {}
	for field in ["damage_dice_count", "damage_die_sides"]:
		var value: Variant = data.get(field)
		if typeof(value) not in [TYPE_INT, TYPE_FLOAT] or value < 1 or floor(value) != value:
			push_error("Weapon %s must be a positive integer: %s" % [field, path])
			return {}
	return data
