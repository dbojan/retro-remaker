## Universal RPG Engine - player.gd
## last modified (local): 2026-11-14-11-25-00
## instructions: on modify, update string.
extends CharacterBody3D

@export var move_speed: float = 4.0

const SELECTED_RING_COLOR := Color(0.2, 0.75, 1.0, 0.85)
const DEFENDING_RING_COLOR := Color(1.0, 0.55, 0.12, 0.95)
const MOVEMENT_STUCK_TIMEOUT := 0.75
const MOVEMENT_PROGRESS_EPSILON := 0.01
const MINIMUM_COMBAT_MOVEMENT := 0.1
const INTERACTION_DISTANCE := 2.5
const EXPLORATION_BLOCKER_CLEARANCE := 0.75

var navigation_agent: NavigationAgent3D
var destination_marker: MeshInstance3D
var selection_ring: MeshInstance3D
var selection_material: StandardMaterial3D
var is_selected := false
var is_defending := false

var has_destination := false
var has_pending_destination := false
var pending_destination: Vector3
var navigation_map_ready := false
var movement_stuck_time := 0.0
var movement_distance := 0.0
var was_in_combat := false
var last_position := Vector3.ZERO
var pending_interaction: Node3D
var pending_enemy: CollisionObject3D
var approach_waypoint_pending := false
var exploration_waypoint_pending := false
var exploration_final_position := Vector3.ZERO
var exploration_detour_retried := false
var approach_final_position := Vector3.ZERO
var approach_route_cache: Dictionary = {}
var approach_route_cache_key := ""
var combat_grid_path := PackedVector3Array()
var combat_grid_costs := PackedInt32Array()
var combat_grid_step_index := 0
var combat_grid_cost_in_action := 0
var combat_grid_active := false
var combat_grid_five_foot_step := false
var combat_grid_withdraw := false

func begin_five_foot_step() -> void:
	combat_grid_five_foot_step = true

func begin_withdraw() -> void:
	combat_grid_withdraw = true

func _ready() -> void:
	add_to_group("party_members")
	$NameLabel.text = name

	navigation_agent = NavigationAgent3D.new()
	navigation_agent.path_desired_distance = 0.5
	navigation_agent.target_desired_distance = 0.5
	add_child(navigation_agent)
	destination_marker = MeshInstance3D.new()
	var marker_mesh := CylinderMesh.new()
	marker_mesh.top_radius = 0.38
	marker_mesh.bottom_radius = 0.38
	marker_mesh.height = 0.025
	destination_marker.mesh = marker_mesh
	var marker_material := StandardMaterial3D.new()
	marker_material.albedo_color = Color(0.95, 0.78, 0.2, 0.85)
	marker_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	marker_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	destination_marker.material_override = marker_material
	destination_marker.visible = false
	get_tree().current_scene.add_child.call_deferred(destination_marker)
	selection_ring = MeshInstance3D.new()
	var selection_mesh := CylinderMesh.new()
	selection_mesh.top_radius = 0.55
	selection_mesh.bottom_radius = 0.55
	selection_mesh.height = 0.025
	selection_ring.mesh = selection_mesh
	selection_material = StandardMaterial3D.new()
	selection_material.albedo_color = Color(0.2, 0.75, 1.0, 0.85)
	selection_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	selection_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	selection_ring.material_override = selection_material
	selection_ring.position.y = 0.02
	selection_ring.visible = false
	add_child(selection_ring)
	if get_tree().get_nodes_in_group("party_members").size() == 1:
		set_selected(true)

func _debug_movement(message: String) -> void:
	var controller := get_tree().current_scene
	if controller != null and controller.has_method("debug_click_movement"):
		controller.call("debug_click_movement", "%s: %s" % [name, message])

func set_selected(selected: bool) -> void:
	if selected != is_selected:
		_debug_movement("selected=%s position=%s" % [selected, global_position])
	is_selected = selected
	if not selected:
		pending_interaction = null
	_refresh_selection_ring()

func set_defending(defending: bool) -> void:
	is_defending = defending
	_refresh_selection_ring()

func _refresh_selection_ring() -> void:
	if selection_ring == null or selection_material == null:
		return

	selection_material.albedo_color = DEFENDING_RING_COLOR if is_defending else SELECTED_RING_COLOR
	selection_ring.visible = is_selected or is_defending

func _unhandled_input(event: InputEvent) -> void:
	if not event is InputEventMouseButton or not event.pressed:
		return

	if event.button_index == MOUSE_BUTTON_LEFT:
		var scene_controller := get_tree().current_scene
		var in_combat: bool = scene_controller.has_method("is_combat_active") and scene_controller.is_combat_active()
		if in_combat:
			if not scene_controller.is_party_member_turn(name):
				return
		elif not is_selected:
			return
		pending_interaction = null

		if scene_controller.has_method("show_interaction_message"):
			scene_controller.call("show_interaction_message", "")
		var hit := _get_mouse_hit(event.position)
		var ground_position: Variant = _get_ground_position(event.position)
		if ground_position == null:
			return
		var destination: Vector3 = ground_position
		var hit_object: Variant = hit.get("collider")
		var hit_name := str(hit_object.get_path()) if hit_object is Node else "none"
		_debug_movement("unhandled click screen=%s hit=%s ground=%s" % [event.position, hit_name, destination])
		if not hit.is_empty():
			var collider: Object = hit["collider"]
			if collider is Node3D and (collider.has_meta("interaction_scene") or collider.has_meta("interaction_text") or collider.has_meta("interaction_dialogue") or collider.has_meta("interaction_item")):
				if in_combat:
					get_viewport().set_input_as_handled()
					return
				if has_destination or has_pending_destination or global_position.distance_to(collider.global_position) > _interaction_distance():
					_approach_interaction(collider, scene_controller)
					get_viewport().set_input_as_handled()
					return
			if collider is Node3D and collider.has_meta("interaction_dialogue") and not has_destination and not has_pending_destination and _is_ground_click_near_interactable(destination, collider):
				if scene_controller.has_method("start_dialogue"):
					scene_controller.call("start_dialogue", str(collider.get_meta("interaction_dialogue")))
					get_viewport().set_input_as_handled()
					return
			if collider is Node3D and collider.has_meta("interaction_item") and not has_destination and not has_pending_destination and _is_ground_click_near_interactable(destination, collider):
				if scene_controller.has_method("pickup_item"):
					var item_collected: bool = bool(scene_controller.call("pickup_item", str(collider.get_meta("interaction_item"))))
					if item_collected:
						collider.queue_free()
				get_viewport().set_input_as_handled()
				return
			if collider is Node3D and collider.has_meta("interaction_scene") and not has_destination and not has_pending_destination and _is_ground_click_near_interactable(destination, collider):
				if collider.has_meta("interaction_key_item"):
					var gate_message := "This gate cannot be opened."
					if scene_controller.has_method("try_open_key_gate"):
						gate_message = str(scene_controller.call("try_open_key_gate", str(collider.get_meta("interaction_key_item"))))
					if not gate_message.is_empty():
						var gate_label := collider.get_node_or_null("InteractionLabel") as Label3D
						if gate_label != null:
							gate_label.text = gate_message
							gate_label.visible = true
						get_viewport().set_input_as_handled()
						return
				var scene_path := str(collider.get_meta("interaction_scene"))
				get_tree().set_meta("selected_party_member", name)
				get_tree().call_deferred("change_scene_to_file", scene_path)
				get_viewport().set_input_as_handled()
				return

			if collider is Node3D and collider.has_meta("interaction_text") and not has_destination and not has_pending_destination and _is_ground_click_near_interactable(destination, collider):
				var interaction_label := collider.get_node_or_null("InteractionLabel") as Label3D
				if interaction_label != null:
					var interaction_message := str(collider.get_meta("interaction_text"))
					if collider.has_meta("interaction_quest_target") and scene_controller.has_method("interact_with_quest_target"):
						interaction_message = str(scene_controller.call("interact_with_quest_target", str(collider.get_meta("interaction_quest_target"))))
					interaction_label.text = interaction_message
					interaction_label.visible = true
				get_viewport().set_input_as_handled()
				return

		if in_combat and not scene_controller.can_party_move(name):
			return
		set_movement_destination(destination)

func set_movement_destination(destination: Vector3) -> void:
	_debug_movement("move requested from=%s to=%s navigation_ready=%s" % [global_position, destination, navigation_map_ready])
	var controller := get_tree().current_scene
	if controller != null and controller.has_method("cancel_pending_charge"):
		controller.cancel_pending_charge(name)
	if controller != null and controller.has_method("begin_opportunity_movement"):
		controller.begin_opportunity_movement(name)
	pending_interaction = null
	pending_enemy = null
	approach_waypoint_pending = false
	exploration_waypoint_pending = false
	exploration_detour_retried = false
	navigation_agent.target_desired_distance = 0.5
	if not has_destination and not has_pending_destination:
		movement_distance = 0.0
	movement_stuck_time = 0.0
	last_position = global_position
	destination_marker.global_position = destination + Vector3.UP * 0.025
	destination_marker.visible = true
	if navigation_map_ready:
		has_destination = true
		_start_navigation_to(destination)
	else:
		pending_destination = destination
		has_pending_destination = true

func cancel_combat_movement() -> void:
	var controller := get_tree().current_scene
	if controller != null and controller.has_method("cancel_pending_charge"):
		controller.cancel_pending_charge(name)
	has_destination = false
	has_pending_destination = false
	pending_enemy = null
	approach_waypoint_pending = false
	exploration_waypoint_pending = false
	combat_grid_active = false
	combat_grid_five_foot_step = false
	combat_grid_withdraw = false
	combat_grid_path.clear()
	combat_grid_costs.clear()
	combat_grid_cost_in_action = 0
	navigation_agent.target_desired_distance = 0.5
	destination_marker.visible = false
	velocity = Vector3.ZERO

func _approach_path_clear(path: PackedVector3Array, blockers: Array[Node3D], allow_escape: bool = false) -> bool:
	for blocker in blockers:
		var point := Vector2(blocker.global_position.x, blocker.global_position.z)
		var first := Vector2(path[0].x, path[0].z) if not path.is_empty() else Vector2.ZERO
		var escaping := allow_escape and first.distance_to(point) < EXPLORATION_BLOCKER_CLEARANCE
		for index in range(1, path.size()):
			var start := Vector2(path[index - 1].x, path[index - 1].z)
			var end := Vector2(path[index].x, path[index].z)
			var closest := Geometry2D.get_closest_point_to_segment(point, start, end)
			if closest.distance_to(point) < EXPLORATION_BLOCKER_CLEARANCE:
				if escaping and closest.distance_to(start) < 0.001 and end.distance_to(point) > start.distance_to(point):
					escaping = end.distance_to(point) < EXPLORATION_BLOCKER_CLEARANCE
					continue
				return false
			escaping = false
	return true

func _approach_path_length(path: PackedVector3Array) -> float:
	var length := 0.0
	for index in range(1, path.size()):
		length += path[index - 1].distance_to(path[index])
	return length

func _exploration_blockers() -> Array[Node3D]:
	var blockers: Array[Node3D] = []
	var controller := get_tree().current_scene
	if controller == null:
		return blockers
	for child in controller.get_children():
		if child == self or not child is CollisionObject3D:
			continue
		var collision_shape := child.get_node_or_null("CollisionShape3D") as CollisionShape3D
		if collision_shape == null or collision_shape.shape == null or collision_shape.global_position.y <= 0.0:
			continue
		blockers.append(child)
	return blockers

func _exploration_detour(destination: Vector3, force: bool = false) -> Dictionary:
	var navigation_map := navigation_agent.get_navigation_map()
	if NavigationServer3D.map_get_iteration_id(navigation_map) == 0:
		return {}
	var blockers := _exploration_blockers()
	if blockers.is_empty():
		return {}
	var direct := NavigationServer3D.map_get_path(navigation_map, global_position, destination, true)
	if direct.size() < 2 or (not force and _approach_path_clear(direct, blockers, true)):
		return {}
	var best_length := INF
	var best: Dictionary = {}
	for blocker in blockers:
		for index in range(16):
			var waypoint := blocker.global_position + Vector3(2.0, 0, 0).rotated(Vector3.UP, TAU * index / 16.0)
			waypoint.y = global_position.y
			var first := NavigationServer3D.map_get_path(navigation_map, global_position, waypoint, true)
			if first.size() < 2 or first[-1].distance_to(waypoint) > 0.3 or not _approach_path_clear(first, blockers, true):
				continue
			var second := NavigationServer3D.map_get_path(navigation_map, waypoint, destination, true)
			if second.size() < 2 or second[-1].distance_to(destination) > 0.3 or not _approach_path_clear(second, blockers):
				continue
			var length := _approach_path_length(first) + _approach_path_length(second)
			if length < best_length:
				best_length = length
				best = {"waypoint": waypoint}
	return best

func _start_navigation_to(destination: Vector3) -> void:
	var controller := get_tree().current_scene
	var in_combat := controller != null and controller.has_method("is_combat_active") and bool(controller.call("is_combat_active"))
	if in_combat and controller.has_method("uses_tactical_grid") and bool(controller.call("uses_tactical_grid")):
		var route: Dictionary = controller.call("get_combat_grid_route", self, destination)
		if combat_grid_five_foot_step and (route.is_empty() or (route["path"] as PackedVector3Array).size() != 2 or int((route["step_costs"] as PackedInt32Array)[0]) != 1):
			combat_grid_five_foot_step = false
			has_destination = false
			destination_marker.visible = false
			controller.call("show_interaction_message", "Choose one adjacent open square for the 5-foot step.")
			return
		if route.is_empty() or not route.has("path") or (route["path"] as PackedVector3Array).size() < 2:
			has_destination = false
			destination_marker.visible = false
			if controller.has_method("show_interaction_message"):
				controller.call("show_interaction_message", "Cannot find a clear grid route.")
			return
		combat_grid_path = route["path"]
		combat_grid_costs = route["step_costs"]
		combat_grid_step_index = 1
		combat_grid_cost_in_action = 0
		combat_grid_active = true
		_start_next_grid_step(controller)
		return
	if not in_combat:
		var detour := _exploration_detour(destination)
		if detour.has("waypoint"):
			exploration_waypoint_pending = true
			exploration_final_position = destination
			navigation_agent.target_desired_distance = 0.15
			navigation_agent.target_position = detour["waypoint"]
			_debug_movement("exploration detour waypoint=%s final=%s" % [detour["waypoint"], destination])
			return
	navigation_agent.target_position = destination
	_debug_movement("navigation target=%s" % destination)

func _start_next_grid_step(scene_controller: Node) -> void:
	if not combat_grid_active:
		return
	if combat_grid_step_index >= combat_grid_path.size():
		combat_grid_active = false
		_finish_movement(true, scene_controller, false if combat_grid_five_foot_step else combat_grid_cost_in_action > 0)
		return
	var step_cost := combat_grid_costs[combat_grid_step_index - 1]
	var movement_limit := int(scene_controller.call("get_combat_movement_limit", name)) * (2 if combat_grid_withdraw else 1)
	if combat_grid_cost_in_action > 0 and combat_grid_cost_in_action + step_cost > movement_limit:
		if combat_grid_withdraw:
			combat_grid_active = false
			has_destination = false
			destination_marker.visible = false
			scene_controller.finish_withdraw(name, combat_grid_cost_in_action > 0)
			return
		combat_grid_cost_in_action = 0
		scene_controller.finish_party_movement(name, true)
		if not scene_controller.can_continue_party_movement(name):
			combat_grid_active = false
			has_destination = false
			destination_marker.visible = false
			return
	if not scene_controller.before_combat_grid_step(self, combat_grid_path[combat_grid_step_index], combat_grid_five_foot_step or (combat_grid_withdraw and combat_grid_step_index == 1)):
		cancel_combat_movement()
		return
	navigation_agent.target_desired_distance = 0.05
	navigation_agent.target_position = combat_grid_path[combat_grid_step_index]
	_debug_movement("grid step=%d cost=%d target=%s" % [combat_grid_step_index, step_cost, navigation_agent.target_position])

func get_enemy_approach_route(enemy: CollisionObject3D) -> Dictionary:
	if not is_instance_valid(enemy):
		return {}
	var navigation_map := navigation_agent.get_navigation_map()
	var map_version := NavigationServer3D.map_get_iteration_id(navigation_map)
	if map_version == 0:
		return {}
	var blockers: Array[Node3D] = []
	var cache_key := "%s:%s:%s:%s" % [global_position, enemy.get_instance_id(), enemy.global_position, map_version]
	for member in get_tree().get_nodes_in_group("party_members"):
		if member != self and member is Node3D:
			blockers.append(member)
			cache_key += ":%s:%s" % [member.get_instance_id(), member.global_position]
	if cache_key == approach_route_cache_key:
		return approach_route_cache
	blockers.append(enemy)
	var best_route: Dictionary = {}
	var best_length := INF
	var destinations: Array[Vector3] = []
	for index in range(16):
		var candidate := enemy.global_position + Vector3(1.5, 0, 0).rotated(Vector3.UP, TAU * index / 16.0)
		candidate.y = global_position.y
		var query := PhysicsRayQueryParameters3D.create(candidate + Vector3.UP * 0.6, enemy.global_position + Vector3.UP * 0.6)
		query.exclude = [get_rid(), enemy.get_rid()]
		if not get_world_3d().direct_space_state.intersect_ray(query).is_empty():
			continue
		destinations.append(candidate)
		var path := NavigationServer3D.map_get_path(navigation_map, global_position, candidate, true)
		if path.size() < 2 or path[-1].distance_to(candidate) > 0.3 or not _approach_path_clear(path, blockers):
			continue
		var length := _approach_path_length(path)
		if length < best_length:
			best_length = length
			best_route = {"path": path, "destination": candidate}
	if best_route.is_empty():
		for blocker in blockers:
			for index in range(8):
				var waypoint := blocker.global_position + Vector3(1.8, 0, 0).rotated(Vector3.UP, TAU * index / 8.0)
				waypoint.y = global_position.y
				var first := NavigationServer3D.map_get_path(navigation_map, global_position, waypoint, true)
				if first.size() < 2 or first[-1].distance_to(waypoint) > 0.3 or not _approach_path_clear(first, blockers):
					continue
				for candidate in destinations:
					var second := NavigationServer3D.map_get_path(navigation_map, waypoint, candidate, true)
					if second.size() < 2 or second[-1].distance_to(candidate) > 0.3 or not _approach_path_clear(second, blockers):
						continue
					var length := _approach_path_length(first) + _approach_path_length(second)
					if length < best_length:
						best_length = length
						var combined := first.duplicate()
						combined.append_array(second.slice(1))
						best_route = {"path": combined, "destination": candidate, "waypoint": waypoint}
	approach_route_cache_key = cache_key
	approach_route_cache = best_route
	return best_route

func move_towards_enemy(enemy: CollisionObject3D) -> bool:
	var controller := get_tree().current_scene
	if controller != null and controller.has_method("uses_tactical_grid") and bool(controller.call("uses_tactical_grid")):
		var grid_route: Dictionary = controller.call("get_combat_grid_approach_route", self, enemy)
		if grid_route.is_empty():
			return false
		set_movement_destination((grid_route["path"] as PackedVector3Array)[-1])
		if not has_destination and not has_pending_destination:
			return false
		pending_enemy = enemy
		return true
	var route := get_enemy_approach_route(enemy)
	if route.is_empty():
		return false
	var destination: Vector3 = route["destination"]
	var waypoint: Vector3 = route.get("waypoint", destination)
	set_movement_destination(waypoint)
	approach_waypoint_pending = route.has("waypoint")
	approach_final_position = destination
	destination_marker.global_position = destination + Vector3.UP * 0.025
	pending_enemy = enemy
	return true

func _approach_interaction(target: Node3D, controller: Node) -> void:
	var navigation_map := navigation_agent.get_navigation_map()
	if NavigationServer3D.map_get_iteration_id(navigation_map) == 0:
		controller.show_interaction_message("Cannot find a route to interact.")
		return
	var best_length := INF
	var best_position := Vector3.ZERO
	var found := false
	for index in range(16):
		var offset := Vector3(1.5, 0, 0).rotated(Vector3.UP, TAU * index / 16.0)
		var candidate := target.global_position + offset
		candidate.y = global_position.y
		var path := NavigationServer3D.map_get_path(navigation_map, global_position, candidate, true)
		if path.is_empty() or path[path.size() - 1].distance_to(candidate) > 0.3:
			continue
		var length := 0.0
		for path_index in range(1, path.size()):
			length += path[path_index - 1].distance_to(path[path_index])
		if length < best_length:
			best_length = length
			best_position = candidate
			found = true
	if not found:
		controller.show_interaction_message("Cannot find a route to interact.")
		return
	set_movement_destination(best_position)
	pending_interaction = target

func interact_by_command(target: Node3D) -> String:
	var controller := get_tree().current_scene
	if controller.is_combat_active():
		return "Cannot interact during combat."
	if has_destination or has_pending_destination:
		return "Cannot interact while moving."
	if global_position.distance_to(target.global_position) > _interaction_distance():
		return "Move closer to interact."
	if target.has_meta("interaction_dialogue"):
		controller.start_dialogue(str(target.get_meta("interaction_dialogue")))
		return controller.dialogue_text.text if controller.dialogue_text != null else "Dialogue opened."
	if target.has_meta("interaction_item"):
		if controller.pickup_item(str(target.get_meta("interaction_item"))):
			target.queue_free()
			return "Item collected."
		return "Item could not be collected."
	if target.has_meta("interaction_scene"):
		if target.has_meta("interaction_key_item"):
			var gate_message: String = controller.try_open_key_gate(str(target.get_meta("interaction_key_item")))
			if not gate_message.is_empty():
				return gate_message
		get_tree().set_meta("selected_party_member", name)
		get_tree().call_deferred("change_scene_to_file", str(target.get_meta("interaction_scene")))
		return "Area transition requested."
	if target.has_meta("interaction_text"):
		if target.has_meta("interaction_quest_target"):
			return controller.interact_with_quest_target(str(target.get_meta("interaction_quest_target")))
		return str(target.get_meta("interaction_text"))
	return "Target cannot be interacted with."

func _get_mouse_hit(mouse_position: Vector2) -> Dictionary:
	var camera := get_viewport().get_camera_3d()
	if camera == null:
		return {}

	var ray_origin := camera.project_ray_origin(mouse_position)
	var ray_end := ray_origin + camera.project_ray_normal(mouse_position) * 1000.0
	var query := PhysicsRayQueryParameters3D.create(ray_origin, ray_end)
	return get_world_3d().direct_space_state.intersect_ray(query)

func _get_ground_position(mouse_position: Vector2) -> Variant:
	var camera := get_viewport().get_camera_3d()
	if camera == null:
		return null

	var ray_origin := camera.project_ray_origin(mouse_position)
	var ray_direction := camera.project_ray_normal(mouse_position)
	if ray_direction.y >= -0.0001:
		return null

	var distance_to_ground := -ray_origin.y / ray_direction.y
	if distance_to_ground < 0.0:
		return null

	var ground_position := ray_origin + ray_direction * distance_to_ground
	if absf(ground_position.x) > 10.0 or absf(ground_position.z) > 10.0:
		return null
	return ground_position

func _is_ground_click_near_interactable(ground_position: Vector3, interactable: Node3D) -> bool:
	var interaction_click_radius := _interaction_distance()
	var ground_point := Vector2(ground_position.x, ground_position.z)
	var interactable_point := Vector2(interactable.global_position.x, interactable.global_position.z)
	return ground_point.distance_to(interactable_point) <= interaction_click_radius

func _interaction_distance() -> float:
	var controller := get_tree().current_scene
	if controller != null and controller.has_method("get_interaction_distance"):
		return float(controller.call("get_interaction_distance", name))
	return INTERACTION_DISTANCE

func _physics_process(_delta: float) -> void:
	if not navigation_map_ready:
		var navigation_map := navigation_agent.get_navigation_map()
		if NavigationServer3D.map_get_iteration_id(navigation_map) == 0:
			velocity = Vector3.ZERO
			move_and_slide()
			return
		navigation_map_ready = true
		if has_pending_destination:
			_start_navigation_to(pending_destination)
			has_destination = true
			has_pending_destination = false

	var scene_controller := get_tree().current_scene
	var in_combat: bool = scene_controller.has_method("is_combat_active") and scene_controller.is_combat_active()
	if in_combat and not was_in_combat:
		movement_distance = 0.0
		pending_interaction = null
		if exploration_waypoint_pending:
			exploration_waypoint_pending = false
			navigation_agent.target_desired_distance = 0.5
			navigation_agent.target_position = exploration_final_position
	if was_in_combat and not in_combat:
		pending_enemy = null
	was_in_combat = in_combat
	if in_combat and not scene_controller.can_continue_party_movement(name):
		pending_enemy = null
		has_destination = false
		has_pending_destination = false
		destination_marker.visible = false
		velocity = Vector3.ZERO
		move_and_slide()
		return

	if not has_destination:
		velocity = Vector3.ZERO
		move_and_slide()
		return

	var next_position := navigation_agent.get_next_path_position()
	if navigation_agent.is_navigation_finished():
		if combat_grid_active and in_combat:
			global_position = combat_grid_path[combat_grid_step_index]
			combat_grid_cost_in_action += combat_grid_costs[combat_grid_step_index - 1]
			combat_grid_step_index += 1
			_start_next_grid_step(scene_controller)
			return
		if exploration_waypoint_pending and not in_combat:
			_debug_movement("detour waypoint reached at=%s; continuing to=%s" % [global_position, exploration_final_position])
			exploration_waypoint_pending = false
			navigation_agent.target_desired_distance = 0.5
			navigation_agent.target_position = exploration_final_position
			return
		if approach_waypoint_pending and is_instance_valid(pending_enemy):
			approach_waypoint_pending = false
			navigation_agent.target_position = approach_final_position
			destination_marker.global_position = approach_final_position + Vector3.UP * 0.025
			return
		_finish_movement(in_combat, scene_controller)
		return

	var direction := global_position.direction_to(next_position)
	velocity.x = direction.x * move_speed
	velocity.z = direction.z * move_speed
	if in_combat and not combat_grid_active and _delta > 0.0:
		var remaining_distance := maxf(float(scene_controller.call("get_combat_movement_limit", name)) - movement_distance, 0.0)
		velocity = velocity.limit_length(remaining_distance / _delta)
	var position_before_move := global_position
	move_and_slide()
	movement_distance += global_position.distance_to(position_before_move)
	if in_combat and not combat_grid_active and movement_distance >= float(scene_controller.call("get_combat_movement_limit", name)) - 0.001:
		movement_distance = 0.0
		scene_controller.finish_party_movement(name, true)
		if not scene_controller.can_continue_party_movement(name):
			has_destination = false
			pending_enemy = null
			destination_marker.visible = false
			velocity = Vector3.ZERO
		elif is_instance_valid(pending_enemy) and global_position.distance_to(pending_enemy.global_position) <= scene_controller.MELEE_ATTACK_RANGE and scene_controller._has_clear_attack_path(self, pending_enemy):
			var enemy := pending_enemy
			pending_enemy = null
			has_destination = false
			destination_marker.visible = false
			velocity = Vector3.ZERO
			scene_controller.finish_enemy_approach(name, enemy)
		return
	movement_stuck_time += _delta
	if movement_stuck_time >= MOVEMENT_STUCK_TIMEOUT:
		if global_position.distance_to(last_position) <= MOVEMENT_PROGRESS_EPSILON:
			_debug_movement("movement stuck at=%s target=%s distance=%s" % [global_position, navigation_agent.target_position, movement_distance])
			if not in_combat and not exploration_detour_retried:
				var retry_destination := exploration_final_position if exploration_waypoint_pending else navigation_agent.target_position
				var retry_detour := _exploration_detour(retry_destination, true)
				if retry_detour.has("waypoint"):
					exploration_detour_retried = true
					exploration_waypoint_pending = true
					exploration_final_position = retry_destination
					navigation_agent.target_desired_distance = 0.15
					navigation_agent.target_position = retry_detour["waypoint"]
					movement_stuck_time = 0.0
					last_position = global_position
					_debug_movement("retrying exploration detour waypoint=%s final=%s" % [retry_detour["waypoint"], retry_destination])
					return
			_finish_movement(in_combat, scene_controller, movement_distance >= MINIMUM_COMBAT_MOVEMENT)
		else:
			last_position = global_position
			movement_stuck_time = 0.0

func _finish_movement(in_combat: bool, scene_controller: Node, spent: bool = true) -> void:
	_debug_movement("movement finished at=%s target=%s combat=%s spent=%s distance=%s" % [global_position, navigation_agent.target_position, in_combat, spent, movement_distance])
	has_destination = false
	movement_stuck_time = 0.0
	destination_marker.visible = false
	velocity = Vector3.ZERO
	move_and_slide()
	if in_combat:
		var enemy := pending_enemy
		pending_enemy = null
		if combat_grid_five_foot_step:
			combat_grid_five_foot_step = false
			scene_controller.finish_five_foot_step(name)
		elif combat_grid_withdraw:
			combat_grid_withdraw = false
			scene_controller.finish_withdraw(name, spent)
		else:
			scene_controller.finish_party_movement(name, spent)
		if is_instance_valid(enemy) or bool(scene_controller.party_charge_pending.get(name, false)):
			scene_controller.finish_enemy_approach(name, enemy)
	elif is_instance_valid(pending_interaction):
		var target := pending_interaction
		pending_interaction = null
		if not target.is_queued_for_deletion() and is_selected and global_position.distance_to(target.global_position) <= _interaction_distance():
			var result := interact_by_command(target)
			scene_controller.show_interaction_message(result)
		else:
			scene_controller.show_interaction_message("Could not reach the target.")
