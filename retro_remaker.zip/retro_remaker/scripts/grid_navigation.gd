## Universal RPG Engine - grid_navigation.gd
## last modified (utc): 2026-11-13-14-00-14
## instructions: on modify, update string.
extends RefCounted

const CELL_SIZE := 1.0
const ACTOR_RADIUS := 0.34
const MAX_SEARCH_NODES := 900

func world_to_cell(position: Vector3) -> Vector2i:
	return Vector2i(roundi(position.x / CELL_SIZE), roundi(position.z / CELL_SIZE))

func cell_to_world(cell: Vector2i, height: float = 0.0) -> Vector3:
	return Vector3(float(cell.x) * CELL_SIZE, height, float(cell.y) * CELL_SIZE)

func find_nearest_open_cell(navigation_map: RID, world: World3D, desired: Vector2i, occupied: Dictionary, excluded: Array[RID]) -> Vector2i:
	for radius in range(0, 8):
		for x in range(desired.x - radius, desired.x + radius + 1):
			for z in range(desired.y - radius, desired.y + radius + 1):
				var cell := Vector2i(x, z)
				if max(abs(cell.x - desired.x), abs(cell.y - desired.y)) != radius:
					continue
				if _cell_is_open(navigation_map, world, cell, occupied, excluded):
					return cell
	return desired

func find_path(navigation_map: RID, world: World3D, start: Vector2i, goal: Vector2i, occupied: Dictionary, excluded: Array[RID], starting_diagonal_count: int = 0, cell_costs: Dictionary = {}, blocked_cells: Dictionary = {}) -> Dictionary:
	if blocked_cells.has(start) or blocked_cells.has(goal) or not _cell_is_open(navigation_map, world, start, {}, excluded) or not _cell_is_open(navigation_map, world, goal, occupied, excluded):
		return {}
	var start_path := PackedVector2Array()
	start_path.append(Vector2(float(start.x), float(start.y)))
	var open: Array[Dictionary] = [{"cell": start, "diagonals": starting_diagonal_count, "cost": 0, "path": start_path}]
	var best_cost: Dictionary = {}
	best_cost[_state_key(start, starting_diagonal_count)] = 0
	var checked := 0
	while not open.is_empty() and checked < MAX_SEARCH_NODES:
		checked += 1
		open.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a["cost"]) + _distance_estimate(a["cell"], goal) < int(b["cost"]) + _distance_estimate(b["cell"], goal))
		var current: Dictionary = open.pop_front()
		var cell: Vector2i = current["cell"]
		if cell == goal:
			var world_path := PackedVector3Array()
			for point in current["path"]:
				world_path.append(cell_to_world(Vector2i(roundi(point.x), roundi(point.y))))
			return {"path": world_path, "cost": int(current["cost"]), "diagonal_count": int(current["diagonals"])}
		for offset in [Vector2i(-1, -1), Vector2i(0, -1), Vector2i(1, -1), Vector2i(-1, 0), Vector2i(1, 0), Vector2i(-1, 1), Vector2i(0, 1), Vector2i(1, 1)]:
			var next: Vector2i = cell + offset
			var diagonal: bool = offset.x != 0 and offset.y != 0
			if blocked_cells.has(next):
				continue
			if not _cell_is_open(navigation_map, world, next, occupied, excluded):
				continue
			if diagonal:
				var horizontal_cell := cell + Vector2i(offset.x, 0)
				var vertical_cell := cell + Vector2i(0, offset.y)
				if blocked_cells.has(horizontal_cell) or blocked_cells.has(vertical_cell) or not _cell_is_open(navigation_map, world, horizontal_cell, occupied, excluded) or not _cell_is_open(navigation_map, world, vertical_cell, occupied, excluded):
					continue
			if not _edge_is_open(world, cell, next, excluded):
				continue
			var diagonals := int(current["diagonals"]) + (1 if diagonal else 0)
			var base_step_cost := 2 if diagonal and diagonals % 2 == 0 else 1
			var step_cost := base_step_cost * maxi(1, int(cell_costs.get(next, 1)))
			var cost := int(current["cost"]) + step_cost
			var key := _state_key(next, diagonals)
			if best_cost.has(key) and int(best_cost[key]) <= cost:
				continue
			best_cost[key] = cost
			var path: PackedVector2Array = current["path"].duplicate()
			path.append(Vector2(float(next.x), float(next.y)))
			open.append({"cell": next, "diagonals": diagonals, "cost": cost, "path": path})
	return {}

func path_step_costs(path: PackedVector3Array, starting_diagonal_count: int = 0, cell_costs: Dictionary = {}) -> PackedInt32Array:
	var costs := PackedInt32Array()
	var diagonal_count := starting_diagonal_count
	for index in range(1, path.size()):
		var start := world_to_cell(path[index - 1])
		var end := world_to_cell(path[index])
		var diagonal := start.x != end.x and start.y != end.y
		var base_step_cost := 1
		if diagonal:
			diagonal_count += 1
			base_step_cost = 2 if diagonal_count % 2 == 0 else 1
		costs.append(base_step_cost * maxi(1, int(cell_costs.get(end, 1))))
	return costs

func _cell_is_open(navigation_map: RID, world: World3D, cell: Vector2i, occupied: Dictionary, excluded: Array[RID]) -> bool:
	if occupied.has(cell):
		return false
	if NavigationServer3D.map_get_iteration_id(navigation_map) == 0:
		return false
	var point := cell_to_world(cell, 0.0)
	if NavigationServer3D.map_get_closest_point(navigation_map, point).distance_to(point) > 0.35:
		return false
	var shape := SphereShape3D.new()
	shape.radius = ACTOR_RADIUS
	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = shape
	query.transform = Transform3D(Basis.IDENTITY, point + Vector3.UP * 0.6)
	query.exclude = excluded
	return world.direct_space_state.intersect_shape(query, 1).is_empty()

func _edge_is_open(world: World3D, start: Vector2i, end: Vector2i, excluded: Array[RID]) -> bool:
	var query := PhysicsRayQueryParameters3D.create(cell_to_world(start, 0.6), cell_to_world(end, 0.6))
	query.exclude = excluded
	return world.direct_space_state.intersect_ray(query).is_empty()

func _state_key(cell: Vector2i, diagonal_count: int) -> String:
	return "%d:%d:%d" % [cell.x, cell.y, diagonal_count % 2]

func _distance_estimate(from: Vector2i, to: Vector2i) -> int:
	return maxi(abs(from.x - to.x), abs(from.y - to.y))
