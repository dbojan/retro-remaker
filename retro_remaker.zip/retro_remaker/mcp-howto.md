<!-- Universal RPG Engine - how to control app remoterly using ai like codex for development.md
last modified (local): 2026-11-13-11-15-57
instructions: on modify, update string.
-->

# Controlling a Godot app with an AI assistant during development

This guide describes the approach used by this project and how to adapt it to another Godot project. It lets an assistant inspect a running app and issue supported commands, including when Godot runs without a graphical display.

## How the pieces fit together

```text
In-game text console ──────────────────────────────┐
                                                   ▼
Terminal or test script ── localhost TCP ── Godot command handler ── game logic
                               ▲
MCP-compatible AI client ── MCP adapter
```

There are three interfaces:

1. **In-game console:** the player types a command in the running game's text field.
2. **Local TCP connection:** a program or terminal command sends a line of text to the running game on `127.0.0.1:47831` and receives one line in reply. This is a project-specific protocol, not MCP.
3. **MCP adapter:** a separate Python process presents named tools to an MCP-compatible client and forwards calls to the same local TCP connection. The client communicates with the adapter over standard input and output, often called *stdio*.

`127.0.0.1` refers to the same machine or network namespace as the process connecting to it. Despite the word “remotely” in this file's name, the current connection is local; it does not provide remote network access. A sandbox may need permission to use local sockets.

The game remains responsible for enforcing its normal rules. For example, a command should not bypass attack range or movement limits. The MCP adapter translates requests; it does not implement game rules or start Godot.

## What this project provides

The command handler and TCP listener are in `scripts/main.gd`; movement and interaction support also use `scripts/player.gd`. The in-game console is in `scenes/combat_ui.tscn`. The optional adapter is `mcp_adapter.py`, and `mcp-requirements.txt` lists its Python dependency.

Commands currently supported are:

| Command | Purpose |
| --- | --- |
| `inspect` | Return area, party and enemy health, party positions and movement status, nearby interactables, quest objective, and combat turn. |
| `select Scout` | Select a party member during exploration. |
| `move 3 4` | Start moving the selected or active character to world coordinates x=3, z=4. |
| `move_enemy Raider 3 4` | Test-only: move a living combat enemy to exact grid coordinates during combat. |
| `interact TrailWarden` | Interact with a nearby target by its scene node name. |
| `dialogue_choice` | Activate the current dialogue choice or close the dialogue. |
| `start_combat Raider` | Start an encounter with the named enemy. |
| `attack Raider` | Attack the active enemy when allowed. |
| `defend` | Use the current party member's main action to defend. |
| `end_turn` | End an active party member's combat turn. |
| `use_potion` | Use a healing potion if available and applicable. |
| `save` / `load` | Use the game's existing save slot during exploration. |

Names in these examples belong to this project. The game reports a rejection if an action is unavailable. Movement and loading happen asynchronously: a successful request does not mean movement or scene loading has already finished. Call `inspect` again to observe the new state. Some responses are JSON and others are plain text; the adapter currently returns them as text.

`move_enemy` is intentionally a test-only command. It uses the Raider’s normal tactical grid path and opportunity-attack checks, but it is not used by normal enemy AI. It is useful for arranging reactions such as Combat Reflexes deterministically.

## Running Godot

Start the project normally in Godot, or run a separate headless instance from a terminal:

```bash
/path/to/godot --headless --path /absolute/path/to/project
```

Replace the paths with the Godot executable and project folder. This project was checked with Godot at `/home/b/apps/Godot_v4.5-dev4_linux.x86_64`. A headless instance has no visible game window, but its game logic and local command listener can run.

Only one instance can listen on the same address and port at a time. Stop other instances or configure a different port before starting another. If the listener cannot start, the game prints a warning.

For isolated headless save/load checks on Linux, give the test instance a separate Godot user-data directory:

```bash
mkdir -p /tmp/godot-ai-test-data
XDG_DATA_HOME=/tmp/godot-ai-test-data /path/to/godot --headless --path /absolute/path/to/project
```

This is appropriate for this project's headless run, which uses `user://` for its save. Verify the save path and any migration behavior in a different project before testing; an editor run of this project instead uses `res://savegame.cfg`. A save command against a normal running game can overwrite its configured save slot.

## Sending a command from a terminal

With the game running, Python's standard library can send one command and print the response:

```bash
python3 -c 'import socket; s = socket.create_connection(("127.0.0.1", 47831), timeout=5); s.sendall(b"inspect\n"); print(s.makefile().readline()); s.close()'
```

The newline after `inspect` marks the end of the request. The game returns one newline-terminated response and closes that connection. Open a new connection for each command. For example, use `b"start_combat Raider\n"` to request combat, or `b"end_turn\n"` to end the current party turn.

If the connection is refused, check that the intended Godot instance is running and that its listener started. If a sandbox blocks the socket, the command may require the sandbox's permission to connect locally.

## Installing the optional MCP adapter

The adapter requires Python and the MCP Python SDK. The Godot game does not require Python or the SDK to run. From this project directory, one isolated installation option is:

```bash
python3 -m venv .venv-mcp
.venv-mcp/bin/pip install -r mcp-requirements.txt
```

Use the Python interpreter from that environment to launch the adapter: `/absolute/path/to/project/.venv-mcp/bin/python`. Alternatively, install the requirements into an existing Python environment and use that environment's `python3`. This project's adapter was checked with MCP Python SDK 2.3.0. Follow your operating system's Python package guidance when installing outside a virtual environment.

The adapter speaks MCP over stdio. An MCP host launches it as a subprocess and communicates through its standard input and output. It connects to the game only when a tool is called. Godot must be running and listening on `127.0.0.1:47831` for the call to reach the game.

## Connecting Codex

For this project's existing Python installation and path, register the adapter with the Codex CLI:

```bash
codex mcp add retro-remaker -- python3 /home/b/data/p_retro_remaker/current/mcp_adapter.py
codex mcp list
```

If using the virtual environment above, replace `python3` with its absolute interpreter path. For another project, replace the adapter path and choose a suitable server name. The registration is in Codex's user configuration, so the path should continue to point to the intended project. Restart or resume Codex if the tools are not yet available in the current session.

Once connected, an assistant can discover tools such as `inspect`, `move`, and `attack` and call them by name. Ask it to inspect the running game or carry out a specific development check. For example: “Inspect the running game, move the selected character near the Trail Warden, and report the result.”

Other MCP-compatible clients, including OpenCode and Claude clients that support local stdio MCP servers, can use the same adapter. Configure each client with its own MCP settings, the Python executable, and the absolute path to `mcp_adapter.py`. Their configuration syntax and permission behavior can differ. This project has checked the adapter with an MCP Python client and confirmed that Codex discovers its tools; it has not yet verified OpenCode or Claude integration.

## Adapting this to another Godot project

1. **Identify the app's existing actions and state.** Find the functions that already perform them. Keep validation, state changes, and gameplay rules in the app.
2. **Add a read-only inspection function first.** Return useful state such as the current scene, entity identifiers, positions, progress, and whether an asynchronous action is still running. Avoid exposing sensitive information.
3. **Add a small command handler.** Start with `inspect`, then route each approved action to existing functions. Return a clear result or rejection. Decide how clients identify actors and targets.
4. **Add a local listener.** For this design, bind only to `127.0.0.1`, accept a newline-terminated command, and send a newline-terminated response. Bound the input size, handle timeouts and disconnects, and keep socket processing from blocking the game loop. The protocol and port can be different in another project, but its adapter must match.
5. **Add a presentation if useful.** An in-game console can call the same command handler. It is optional for a headless or automated client.
6. **Create a separate MCP adapter.** Register a named tool for each supported operation, validate tool arguments, forward requests to the local listener, and return the result. Keep the adapter's Python dependency separate from the Godot app if end users should not need it.
7. **Check the complete path.** Run an isolated headless instance; check the local protocol, then use an MCP client to discover and call tools. Check successful operations, rejected actions, asynchronous completion, and save isolation as appropriate.
8. **Configure each AI client.** Point it to the adapter and the correct Python interpreter. Verify that the client discovers the tools and that calls reach the intended running instance.

The current adapter and commands are a prototype, not a general drop-in Godot plugin. They use this project's port, scene node names, action rules, and response format. Review and adapt them before using them in another app. If an app needs access from another machine, design and secure that connection separately rather than simply exposing the current localhost listener.
