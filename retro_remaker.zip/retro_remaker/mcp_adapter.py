# Universal RPG Engine - mcp_adapter.py
# last modified (local): 2026-11-14-12-07-35
# instructions: on modify, update string.
"""Optional MCP adapter for a running Universal RPG Engine instance."""

import math
import socket

from mcp.server import MCPServer

server = MCPServer("Universal RPG Engine")


def _command(command: str) -> str:
    try:
        with socket.create_connection(("127.0.0.1", 47831), timeout=5) as connection:
            connection.settimeout(5)
            connection.sendall((command + "\n").encode("utf-8"))
            with connection.makefile("rb") as response:
                line = response.readline(65537)
        if not line or len(line) > 65536 or not line.endswith(b"\n"):
            return "Game connection returned an incomplete or oversized response."
        return line.decode("utf-8").rstrip("\r\n")
    except (OSError, UnicodeError) as error:
        return f"Could not communicate with the game: {error}"


def _target(value: str) -> str:
    if not value or not all(char.isascii() and (char.isalnum() or char == "_") for char in value):
        raise ValueError("Use a single target name containing letters, numbers, or underscores.")
    return value


@server.tool()
def inspect() -> str:
    """Inspect the area, party, enemies, nearby interactables, and quest."""
    return _command("inspect")


@server.tool()
def start_combat(enemy: str) -> str:
    """Start combat with the named enemy in the current area."""
    return _command(f"start_combat {_target(enemy)}")


@server.tool()
def end_turn() -> str:
    """End the active party member's combat turn."""
    return _command("end_turn")


@server.tool()
def move(x: float, z: float) -> str:
    """Move the selected or active character to area coordinates; movement is asynchronous."""
    if not math.isfinite(x) or not math.isfinite(z):
        raise ValueError("Coordinates must be finite numbers.")
    return _command(f"move {x} {z}")


@server.tool()
def move_enemy(enemy: str, x: float, z: float) -> str:
    """Test-only: move a living combat enemy to exact grid coordinates."""
    if not math.isfinite(x) or not math.isfinite(z):
        raise ValueError("Coordinates must be finite numbers.")
    return _command(f"move_enemy {_target(enemy)} {x} {z}")


@server.tool()
def five_foot_step(x: float, z: float) -> str:
    """Take one adjacent 5-foot grid step without spending an action; movement is asynchronous."""
    if not math.isfinite(x) or not math.isfinite(z):
        raise ValueError("Coordinates must be finite numbers.")
    return _command(f"five_foot_step {x} {z}")


@server.tool()
def attack(enemy: str) -> str:
    """Attack the named active enemy if the current character can do so."""
    return _command(f"attack {_target(enemy)}")


@server.tool()
def charge(enemy: str) -> str:
    """Charge the named active enemy, using both actions for a +2 melee attack."""
    return _command(f"charge {_target(enemy)}")


@server.tool()
def withdraw(x: float, z: float) -> str:
    """Withdraw up to double speed; the first grid step does not provoke attacks."""
    if not math.isfinite(x) or not math.isfinite(z):
        raise ValueError("Coordinates must be finite numbers.")
    return _command(f"withdraw {x} {z}")


@server.tool()
def full_attack(enemy: str) -> str:
    """Make every iterative melee attack against the named adjacent enemy, using both actions."""
    return _command(f"full_attack {_target(enemy)}")


@server.tool()
def defend() -> str:
    """Use the active character's main action to defend."""
    return _command("defend")


@server.tool()
def use_potion() -> str:
    """Use a healing potion on the selected or active character."""
    return _command("use_potion")


@server.tool()
def equip(weapon: str) -> str:
    """Equip an available weapon for the selected character during exploration."""
    return _command(f"equip {_target(weapon)}")


@server.tool()
def select(character: str) -> str:
    """Select a party member during exploration."""
    return _command(f"select {_target(character)}")


@server.tool()
def choose_feat(feat: str) -> str:
    """Choose an available feat for the selected party member during exploration."""
    return _command(f"choose_feat {_target(feat)}")


@server.tool()
def interact(target: str) -> str:
    """Interact with a nearby object using its scene node name."""
    return _command(f"interact {_target(target)}")


@server.tool()
def dialogue_choice() -> str:
    """Activate the current dialogue choice or close the dialogue."""
    return _command("dialogue_choice")


@server.tool()
def dialogue_influence() -> str:
    """Use the available Influence dialogue choice."""
    return _command("dialogue_influence")


@server.tool()
def dialogue_lore() -> str:
    """Use the available Lore dialogue choice."""
    return _command("dialogue_lore")


@server.tool()
def dialogue_decline() -> str:
    """Decline the available quest offer."""
    return _command("dialogue_decline")


@server.tool()
def save() -> str:
    """Save the game to its configured save slot during exploration."""
    return _command("save")


@server.tool()
def load() -> str:
    """Load the configured save slot; the scene change is asynchronous."""
    return _command("load")


if __name__ == "__main__":
    server.run()
